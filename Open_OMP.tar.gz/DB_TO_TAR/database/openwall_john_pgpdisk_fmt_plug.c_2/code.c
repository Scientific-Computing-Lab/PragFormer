for (j = 0; j < iterations; j++)
{
  sph_sha1(&ctx, hash, bytesThisTime);
  sph_sha1(&ctx, ((uint8_t *) (&j)) + 3, 1);
}
