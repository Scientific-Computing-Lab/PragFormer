for (i = 0; i < progs->numfunctions; i++)
{
  printf("------------------------\nFUNCTION %d\n------------------------\n", i);
  printf("first_statement = %d\n", pr_functions[i].first_statement);
  printf("param_start = %d\n", pr_functions[i].parm_start);
  printf("s_name = %s\n", PR_GetString(pr_functions[i].s_name));
  printf("s_file = %s\n", PR_GetString(pr_functions[i].s_file));
  printf("num_params = %d\n", pr_functions[i].numparms);
  printf("locals = %d\n\n", pr_functions[i].locals);
}
