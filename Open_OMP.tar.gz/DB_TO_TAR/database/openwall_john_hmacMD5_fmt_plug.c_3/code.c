for (i = 0; i < len; i++)
{
  ipad[index][i] ^= key[i];
  opad[index][i] ^= key[i];
}
