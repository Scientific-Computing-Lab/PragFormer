for (i = 0; i < 8; i++)
  binary_salt.u8[i] = (atoi16[ARCH_INDEX(pos[i * 2])] << 4) + atoi16[ARCH_INDEX(pos[(i * 2) + 1])];
