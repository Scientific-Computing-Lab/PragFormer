for (bumpcount = 0; bumpcount < numbumps; bumpcount++)
{
  for (i = 0; i < 3; i++)
    end[i] = ent->v.origin[i] + (time_left * ent->v.velocity[i]);

  trace = SV_Move(ent->v.origin, ent->v.mins, ent->v.maxs, end, false, ent);
  if (trace.allsolid)
  {
    {
      ent->v.velocity[0] = vec3_origin[0];
      ent->v.velocity[1] = vec3_origin[1];
      ent->v.velocity[2] = vec3_origin[2];
    }
    ;
    return 3;
  }

  if (trace.fraction > 0)
  {
    {
      ent->v.origin[0] = trace.endpos[0];
      ent->v.origin[1] = trace.endpos[1];
      ent->v.origin[2] = trace.endpos[2];
    }
    ;
    {
      original_velocity[0] = ent->v.velocity[0];
      original_velocity[1] = ent->v.velocity[1];
      original_velocity[2] = ent->v.velocity[2];
    }
    ;
    numplanes = 0;
  }

  if (trace.fraction == 1)
    break;

  if (!trace.ent)
    SV_Error("SV_FlyMove: !trace.ent");

  if (trace.plane.normal[2] > 0.7)
  {
    blocked |= 1;
    if (trace.ent->v.solid == 4)
    {
      ent->v.flags = ((int) ent->v.flags) | 512;
      ent->v.groundentity = ((byte *) trace.ent) - ((byte *) sv.edicts);
    }

  }

  if (!trace.plane.normal[2])
  {
    blocked |= 2;
    if (steptrace)
      *steptrace = trace;

  }

  SV_Impact(ent, trace.ent);
  if (ent->free)
    break;

  time_left -= time_left * trace.fraction;
  if (numplanes >= 5)
  {
    {
      ent->v.velocity[0] = vec3_origin[0];
      ent->v.velocity[1] = vec3_origin[1];
      ent->v.velocity[2] = vec3_origin[2];
    }
    ;
    return 3;
  }

  {
    planes[numplanes][0] = trace.plane.normal[0];
    planes[numplanes][1] = trace.plane.normal[1];
    planes[numplanes][2] = trace.plane.normal[2];
  }
  ;
  numplanes++;
  for (i = 0; i < numplanes; i++)
  {
    ClipVelocity(original_velocity, planes[i], new_velocity, 1);
    for (j = 0; j < numplanes; j++)
      if (j != i)
    {
      if ((((new_velocity[0] * planes[j][0]) + (new_velocity[1] * planes[j][1])) + (new_velocity[2] * planes[j][2])) < 0)
        break;

    }


    if (j == numplanes)
      break;

  }

  if (i != numplanes)
  {
    {
      ent->v.velocity[0] = new_velocity[0];
      ent->v.velocity[1] = new_velocity[1];
      ent->v.velocity[2] = new_velocity[2];
    }
    ;
  }
  else
  {
    if (numplanes != 2)
    {
      {
        ent->v.velocity[0] = vec3_origin[0];
        ent->v.velocity[1] = vec3_origin[1];
        ent->v.velocity[2] = vec3_origin[2];
      }
      ;
      return 7;
    }

    CrossProduct(planes[0], planes[1], dir);
    d = ((dir[0] * ent->v.velocity[0]) + (dir[1] * ent->v.velocity[1])) + (dir[2] * ent->v.velocity[2]);
    VectorScale(dir, d, ent->v.velocity);
  }

  if ((((ent->v.velocity[0] * primal_velocity[0]) + (ent->v.velocity[1] * primal_velocity[1])) + (ent->v.velocity[2] * primal_velocity[2])) <= 0)
  {
    {
      ent->v.velocity[0] = vec3_origin[0];
      ent->v.velocity[1] = vec3_origin[1];
      ent->v.velocity[2] = vec3_origin[2];
    }
    ;
    return blocked;
  }

}

void SV_Impact(edict_t *e1, edict_t *e2)
{
  int old_self;
  int old_other;
  old_self = pr_global_struct->self;
  old_other = pr_global_struct->other;
  pr_global_struct->time = sv.time;
  if (e1->v.touch && (e1->v.solid != 0))
  {
    pr_global_struct->self = ((byte *) e1) - ((byte *) sv.edicts);
    pr_global_struct->other = ((byte *) e2) - ((byte *) sv.edicts);
    PR_ExecuteProgram(e1->v.touch);
  }

  if (e2->v.touch && (e2->v.solid != 0))
  {
    pr_global_struct->self = ((byte *) e2) - ((byte *) sv.edicts);
    pr_global_struct->other = ((byte *) e1) - ((byte *) sv.edicts);
    PR_ExecuteProgram(e2->v.touch);
  }

  pr_global_struct->self = old_self;
  pr_global_struct->other = old_other;
}


int ClipVelocity(vec3_t in, vec3_t normal, vec3_t out, float overbounce)
{
  float backoff;
  float change;
  int i;
  int blocked;
  blocked = 0;
  if (normal[2] > 0)
    blocked |= 1;

  if (!normal[2])
    blocked |= 2;

  backoff = (((in[0] * normal[0]) + (in[1] * normal[1])) + (in[2] * normal[2])) * overbounce;
  for (i = 0; i < 3; i++)
  {
    change = normal[i] * backoff;
    out[i] = in[i] - change;
    if ((out[i] > (-0.1)) && (out[i] < 0.1))
      out[i] = 0;

  }

  return blocked;
}

