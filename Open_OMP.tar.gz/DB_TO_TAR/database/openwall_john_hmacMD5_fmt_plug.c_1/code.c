for (i = pos; i < ((16 * 2) + pos); i++)
{
  if (!(((('0' <= ciphertext[i]) && (ciphertext[i] <= '9')) || (('a' <= ciphertext[i]) && (ciphertext[i] <= 'f'))) || (('A' <= ciphertext[i]) && (ciphertext[i] <= 'F'))))
    return 0;

}
