for (i = 0; i < 64; i++)
{
  long value = -((long) ((plaintext[i >> 3] >> (7 - (i & 7))) & 1));
  DES_bs_P[i] = value;
}
