for (index = 0; index < count; index += 3)
{
  int i;
  int j;
  if (keys_changed)
  {
    char *k0 = saved_key[index];
    char *k1 = saved_key[index + 1];
    char *k2 = saved_key[index + 2];
    unsigned char digest16[3][16];
    domino_big_md_3((unsigned char *) k0, strlen(k0), (unsigned char *) k1, strlen(k1), (unsigned char *) k2, strlen(k2), digest16[0], digest16[1], digest16[2]);
    for (i = 0, j = 6; i < 14; i++, j += 2)
    {
      const char *hex2 = hex_table[ARCH_INDEX(digest16[0][i])];
      digest34[index][j] = hex2[0];
      digest34[index][j + 1] = hex2[1];
      hex2 = hex_table[ARCH_INDEX(digest16[1][i])];
      digest34[index + 1][j] = hex2[0];
      digest34[index + 1][j + 1] = hex2[1];
      hex2 = hex_table[ARCH_INDEX(digest16[2][i])];
      digest34[index + 2][j] = hex2[0];
      digest34[index + 2][j + 1] = hex2[1];
    }

  }

  if (salt_changed)
  {
    digest34[index + 2][0] = (digest34[index + 1][0] = (digest34[index][0] = cur_salt->salt[0]));
    digest34[index + 2][1] = (digest34[index + 1][1] = (digest34[index][1] = cur_salt->salt[1]));
    digest34[index + 2][2] = (digest34[index + 1][2] = (digest34[index][2] = cur_salt->salt[2]));
    digest34[index + 2][3] = (digest34[index + 1][3] = (digest34[index][3] = cur_salt->salt[3]));
    digest34[index + 2][4] = (digest34[index + 1][4] = (digest34[index][4] = cur_salt->salt[4]));
    digest34[index + 2][5] = (digest34[index + 1][5] = (digest34[index][5] = '('));
  }

  domino_big_md_3_34(digest34[index], digest34[index + 1], digest34[index + 2], (unsigned char *) crypt_out[index], (unsigned char *) crypt_out[index + 1], (unsigned char *) crypt_out[index + 2]);
  for (i = 0; i < 3; i++)
  {
    unsigned char buffer[22 + 1] = {0};
    unsigned char tmp_hash[(22 + 1) + 3] = {0};
    memcpy(tmp_hash, cur_salt->salt, 5);
    memcpy(tmp_hash + 5, crypt_out[index + i], 16);
    domino_encode(tmp_hash, buffer);
    sprintf((char *) tmp_hash, "(G%s)", buffer);
    pbkdf2_sha1(tmp_hash, 22, cur_salt->salt, 16, cur_salt->iterations, (unsigned char *) crypt_out_real[index + i], 8, 0);
  }

}

static void domino_big_md_3(unsigned char *in0, unsigned int size0, unsigned char *in1, unsigned int size1, unsigned char *in2, unsigned int size2, unsigned char *out0, unsigned char *out1, unsigned char *out2)
{
  unsigned char state[3][16] = {{0}, {0}, {0}};
  unsigned char checksum[3][16] = {{0}, {0}, {0}};
  unsigned char block[3][16];
  unsigned int min;
  unsigned int curpos = 0;
  unsigned int curpos0;
  unsigned int curpos1;
  unsigned int curpos2;
  min = (size0 < size1) ? (size0) : (size1);
  if (size2 < min)
    min = size2;

  while ((curpos + 15) < min)
  {
    mdtransform_3(state, checksum, in0 + curpos, in1 + curpos, in2 + curpos);
    curpos += 16;
  }

  curpos0 = curpos;
  while ((curpos0 + 15) < size0)
  {
    mdtransform_1(state[0], checksum[0], in0 + curpos0);
    curpos0 += 16;
  }

  curpos1 = curpos;
  while ((curpos1 + 15) < size1)
  {
    mdtransform_1(state[1], checksum[1], in1 + curpos1);
    curpos1 += 16;
  }

  curpos2 = curpos;
  while ((curpos2 + 15) < size2)
  {
    mdtransform_1(state[2], checksum[2], in2 + curpos2);
    curpos2 += 16;
  }

  {
    unsigned int pad0 = size0 - curpos0;
    unsigned int pad1 = size1 - curpos1;
    unsigned int pad2 = size2 - curpos2;
    memcpy(block[0], in0 + curpos0, pad0);
    memcpy(block[1], in1 + curpos1, pad1);
    memcpy(block[2], in2 + curpos2, pad2);
    memset(block[0] + pad0, 16 - pad0, 16 - pad0);
    memset(block[1] + pad1, 16 - pad1, 16 - pad1);
    memset(block[2] + pad2, 16 - pad2, 16 - pad2);
    mdtransform_3(state, checksum, block[0], block[1], block[2]);
  }
  mdtransform_norecalc_3(state, checksum[0], checksum[1], checksum[2]);
  memcpy(out0, state[0], 16);
  memcpy(out1, state[1], 16);
  memcpy(out2, state[2], 16);
}


static void domino_big_md_3_34(unsigned char *in0, unsigned char *in1, unsigned char *in2, unsigned char *out0, unsigned char *out1, unsigned char *out2)
{
  unsigned char state[3][16] = {{0}, {0}, {0}};
  unsigned char checksum[3][16] = {{0}, {0}, {0}};
  unsigned char block[3][16];
  mdtransform_3(state, checksum, in0, in1, in2);
  mdtransform_3(state, checksum, in0 + 16, in1 + 16, in2 + 16);
  memcpy(block[0], in0 + 32, 2);
  memcpy(block[1], in1 + 32, 2);
  memcpy(block[2], in2 + 32, 2);
  memset(block[0] + 2, 14, 14);
  memset(block[1] + 2, 14, 14);
  memset(block[2] + 2, 14, 14);
  mdtransform_3(state, checksum, block[0], block[1], block[2]);
  mdtransform_norecalc_3(state, checksum[0], checksum[1], checksum[2]);
  memcpy(out0, state[0], 16);
  memcpy(out1, state[1], 16);
  memcpy(out2, state[2], 16);
}


static void domino_encode(unsigned char *salt, unsigned char *hash)
{
  unsigned char output[25] = {0};
  int byte10 = ((char) salt[3]) + 4;
  if (byte10 > 255)
    byte10 = byte10 - 256;

  salt[3] = (char) byte10;
  domino_base64_encode(((salt[0] << 16) | (salt[1] << 8)) | salt[2], 4, output);
  domino_base64_encode(((salt[3] << 16) | (salt[4] << 8)) | salt[5], 4, output + 4);
  domino_base64_encode(((salt[6] << 16) | (salt[7] << 8)) | salt[8], 4, output + 8);
  domino_base64_encode(((salt[9] << 16) | (salt[10] << 8)) | salt[11], 4, output + 12);
  domino_base64_encode(((salt[12] << 16) | (salt[13] << 8)) | salt[14], 4, output + 16);
  output[19] = '\x00';
  memcpy(hash, output, 20);
}


static void pbkdf2_sha1(const unsigned char *K, int KL, const unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[20 / (sizeof(uint32_t))];
    unsigned char out[20];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  sph_sha1_context ipad;
  sph_sha1_context opad;
  _pbkdf2_sha1_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (20 - 1)) / 20;
  loop = (skip_bytes / 20) + 1;
  skip_bytes %= 20;
  while (loop <= loops)
  {
    _pbkdf2_sha1(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 20) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}

