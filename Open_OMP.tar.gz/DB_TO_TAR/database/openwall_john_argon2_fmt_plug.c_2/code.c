for (i = 0; i < sc_threads; i++)
{
  free_region_t(&memory[i]);
  {
    if (pseudo_rands[i])
    {
      free(pseudo_rands[i]);
      pseudo_rands[i] = 0;
    }

  }
  ;
}
