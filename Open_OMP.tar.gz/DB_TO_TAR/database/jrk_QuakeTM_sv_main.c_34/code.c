for (i = 0, cl = svs.clients; i < 32; i++, cl++)
{
  switch (cl->state)
  {
    case cs_free:
      sprintf(state, "free\t");
      break;

    case cs_zombie:
      sprintf(state, "zombie\t");
      printf("%d\t%s\n", i, state);
      break;

    case cs_connected:
      sprintf(state, "connected\t");
      sprintf(state, "%s%s\t", state, cl->name);
      printf("%d\t%s\n", i, state);
      break;

    case cs_spawned:
      sprintf(state, "spawned\t");
      sprintf(state, "%s%s\t\t", state, cl->name);
      if (((cl->edict->v.origin[0] != old_origin[i][0]) || (cl->edict->v.origin[1] != old_origin[i][1])) || (cl->edict->v.origin[2] != old_origin[i][2]))
    {
      sprintf(state, "%smoved : ( %f , %f , %f ) ", state, old_origin[i][0], old_origin[i][1], old_origin[i][2]);
      sprintf(state, "%s-> ( %f , %f , %f )", state, cl->edict->v.origin[0], cl->edict->v.origin[1], cl->edict->v.origin[2]);
      old_origin[i][0] = cl->edict->v.origin[0];
      old_origin[i][1] = cl->edict->v.origin[1];
      old_origin[i][2] = cl->edict->v.origin[2];
    }

      printf("%d\t%s\n", i, state);
      break;

  }

}
