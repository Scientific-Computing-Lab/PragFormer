for (index = 0; index < count; index++)
  if (((uint32_t *) binary)[0] == crypt_key[index][0])
  return 1;

