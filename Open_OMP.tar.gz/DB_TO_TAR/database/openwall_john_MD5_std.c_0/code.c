for (t = 0; t < (n * (((sizeof(MD5_std_combined)) + (64 - 1)) & (~(64 - 1)))); t += ((sizeof(MD5_std_combined)) + (64 - 1)) & (~(64 - 1)))
{
  if (salt_changed)
    MD5_std_set_salt_for_thread(t, saved_salt);

  MD5_std_crypt_for_thread(t);
}

inline static void MD5_std_set_salt_for_thread(int t, char *salt)
{
  int length;
  for (length = 0; (length < 8) && salt[length]; length++)
    ;

  memcpy((*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool[0].s, salt, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool[0].l.s = length);
  if (salt[8] == 2)
  {
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prefix = "$1$";
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prelen = (sizeof("$1$")) - 1;
  }
  else
    if (salt[8] == 1)
  {
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prefix = "$apr1$";
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prelen = (sizeof("$apr1$")) - 1;
  }
  else
    if (salt[8] == 3)
  {
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prefix = "";
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prelen = 0;
  }



}


inline static void MD5_std_crypt_for_thread(int t)
{
  int length;
  int index;
  int mask;
  MD5_pattern *line;
  memcpy((*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.ps.b, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.p.b, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.ps.b[(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->s, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.s);
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p + (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.s;
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.ps.b[(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps + 16], PADDING, 40 - (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps);
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.ps.w[14] = ((*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps + 16) << 3;
  memcpy((*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.psp.b, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.ps.b, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.psp.b[(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.p.b, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p);
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps + (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p;
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.psp.b[(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp + 16], PADDING, 40 - (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp);
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.psp.w[14] = ((*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp + 16) << 3;
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.sp.b[16], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->s, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.s);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.sp.b[16 + (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.s], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.p.b, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.sp.b[16 + (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps], PADDING, 40 - (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps);
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.sp.w[14] = ((*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps + 16) << 3;
  {
    MD5_word *dptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.sp.w;
    MD5_word *sptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.sp.w;
    int loop_count = 14;
    MD5_word mask = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).data.masks[1];
    do
    {
      MD5_word tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
      tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
    }
    while (loop_count -= 2);
  }
  ;
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.spp.b[16], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->s, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.s);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.spp.b[16 + (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.s], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.pp.b, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.pp);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.spp.b[16 + (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp], PADDING, 40 - (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp);
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.spp.w[14] = ((*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp + 16) << 3;
  {
    MD5_word *dptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.spp.w;
    MD5_word *sptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->e.spp.w;
    int loop_count = 14;
    MD5_word mask = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).data.masks[1];
    do
    {
      MD5_word tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
      tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
    }
    while (loop_count -= 2);
  }
  ;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[0][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[2][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[3][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[5][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[6][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[8][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[9][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[11][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[12][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[14][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[15][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[17][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[18][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[20][0].length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp;
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.psp.b, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].b[(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp], PADDING, 56 - (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp);
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w[14] = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp << 3;
  {
    MD5_word *dptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w;
    MD5_word *sptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w;
    int loop_count = 14;
    MD5_word mask = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).data.masks[1];
    do
    {
      MD5_word tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
      tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
    }
    while (loop_count -= 2);
  }
  ;
  MD5_body_for_thread(t, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).out[0]);
  {
    MD5_word *dptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).out[0];
    MD5_word *sptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).out[0];
    int loop_count = 4;
    MD5_word mask = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).data.masks[1];
    do
    {
      MD5_word tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
      tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
    }
    while (loop_count -= 2);
  }
  ;
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.p.b, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].b[(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prefix, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prelen);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].b[(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p + (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prelen], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->s, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.s);
  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].b[(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.ps + (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prelen], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).out[0], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p);
  length = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.psp + (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).prelen;
  if (mask = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->l.p)
    do
  {
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].b[length++] = (mask & 1) ? (0) : ((*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool->o.p.b[0]);
  }
  while (mask >>= 1);

  memcpy(&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].b[length], PADDING, 56 - length);
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w[14] = length << 3;
  {
    MD5_word *dptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w;
    MD5_word *sptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w;
    int loop_count = 14;
    MD5_word mask = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).data.masks[1];
    do
    {
      MD5_word tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
      tmp = *(sptr++);
      tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
      *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
    }
    while (loop_count -= 2);
  }
  ;
  MD5_body_for_thread(t, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[0][0].even->w);
  index = 500;
  line = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[0];
  do
  {
    MD5_body_for_thread(t, line[0].even->w, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).out[0]);
    {
      MD5_word *dptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).out[0];
      MD5_word *sptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).out[0];
      int loop_count = 4;
      MD5_word mask = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).data.masks[1];
      do
      {
        MD5_word tmp = *(sptr++);
        tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
        *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
        tmp = *(sptr++);
        tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
        *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
      }
      while (loop_count -= 2);
    }
    ;
    memcpy(&line[0].odd->b[line[0].length], (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).out[0], 16);
    {
      MD5_word *dptr = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w;
      MD5_word *sptr = line[0].odd->w;
      int loop_count = 14;
      MD5_word mask = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).data.masks[1];
      do
      {
        MD5_word tmp = *(sptr++);
        tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
        *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
        tmp = *(sptr++);
        tmp = (tmp << 16) | (((MD5_word) tmp) >> (32 - 16));
        *(dptr++) = ((tmp & mask) << 8) | ((tmp >> 8) & mask);
      }
      while (loop_count -= 2);
    }
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w[14] = line[0].odd->w[14];
    if ((++line) > (&(*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[20][0]))
      line = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[0];

    MD5_body_for_thread(t, (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._block[0].w, line[0].even->w);
  }
  while (--index);
  memcpy((*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).out[0], line[0].even, 16);
}

