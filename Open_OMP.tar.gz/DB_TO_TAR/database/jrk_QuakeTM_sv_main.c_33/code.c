for (i = 0; i < 32; i++)
{
  old_origin[i][0] = 0;
  old_origin[i][1] = 0;
  old_origin[i][2] = 0;
}
