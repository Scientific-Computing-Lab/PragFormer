for (i = 0; i < max_threads; i++)
  yescrypt_init_local(&local[i]);
