for (axis = 0; axis <= 2; axis++)
{
  fprintf(stderr, "%s: doing axis %d projections ... \n", me, axis);
  fflush(stderr);
  if (ninspect_proj(nproj[axis], nin, axis, smart, amount))
  {
    fprintf(stderr, "ERROR\n");
    sprintf(err, "%s: trouble doing projections for axis %d", me, axis);
    biffAdd("ninspect", err);
    airMopError(mop);
    abort = 1;
  }

  fprintf(stderr, "%s: ... done with axis %d projections\n", me, axis);
}

int ninspect_proj(Nrrd *nout, Nrrd *nin, int axis, int smart, float amount)
{
  char me[] = "ninspect_proj";
  char err[BIFF_STRLEN];
  airArray *mop;
  Nrrd *ntmpA;
  Nrrd *ntmpB;
  Nrrd *nrgb[3];
  int bins;
  if (!(nout && nin))
  {
    sprintf(err, "%s: got NULL pointer", me);
    biffAdd("ninspect", err);
    return 1;
  }

  if (!((0 <= axis) && (axis <= 2)))
  {
    sprintf(err, "%s: given axis %d outside valid range [0,1,2]", me, axis);
    biffAdd("ninspect", err);
    return 1;
  }

  mop = airMopNew();
  airMopAdd(mop, ntmpA = nrrdNew(), (airMopper) nrrdNuke, airMopAlways);
  airMopAdd(mop, ntmpB = nrrdNew(), (airMopper) nrrdNuke, airMopAlways);
  airMopAdd(mop, nrgb[0] = nrrdNew(), (airMopper) nrrdNuke, airMopAlways);
  airMopAdd(mop, nrgb[1] = nrrdNew(), (airMopper) nrrdNuke, airMopAlways);
  airMopAdd(mop, nrgb[2] = nrrdNew(), (airMopper) nrrdNuke, airMopAlways);
  bins = 3000;
  if ((((((((nrrdProject(ntmpA, nin, axis, nrrdMeasureSum, nrrdTypeDefault) || nrrdHistoEq(ntmpB, ntmpA, 0, bins, smart, amount)) || nrrdQuantize(nrgb[0], ntmpB, 0, 8)) || nrrdProject(ntmpA, nin, axis, nrrdMeasureVariance, nrrdTypeDefault)) || nrrdHistoEq(ntmpB, ntmpA, 0, bins, smart, amount)) || nrrdQuantize(nrgb[1], ntmpB, 0, 8)) || nrrdProject(ntmpA, nin, axis, nrrdMeasureMax, nrrdTypeDefault)) || nrrdQuantize(nrgb[2], ntmpA, 0, 8)) || nrrdJoin(nout, (const Nrrd **) nrgb, 3, 0, 1))
  {
    sprintf(err, "%s: trouble with nrrd operations", me);
    biffMove("ninspect", err, nrrdBiffKey);
    airMopError(mop);
    return 1;
  }

  airMopOkay(mop);
  return 0;
}

