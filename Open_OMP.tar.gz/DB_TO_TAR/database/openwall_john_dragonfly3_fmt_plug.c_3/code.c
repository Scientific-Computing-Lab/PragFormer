for (len = 0; ciphertext[len] != '$'; len++)
  ;
