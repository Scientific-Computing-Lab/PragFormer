for (i = 0; Dynamic_curdat.dynamic_FUNCTIONS[i]; ++i)
  (*Dynamic_curdat.dynamic_FUNCTIONS[i])(0, m_Dynamic_Count, 0);
