for (index = 0; index < count; index += 1)
{
  hash_plugin_check_hash(index);
}

static void hash_plugin_check_hash(int index)
{
  unsigned char hmacsha1_key_[20];
  unsigned char aes_key_[32];
  int j;
  if (cur_salt->headerver == 1)
  {
    unsigned char derived_key[32];
    const char *password = saved_key[index];
    pbkdf2_sha1((const unsigned char *) password, strlen(password), cur_salt->salt, 20, cur_salt->iterations, derived_key, 32, 0);
    j = 0;
    if (apple_des3_ede_unwrap_key1(cur_salt->wrapped_aes_key, cur_salt->len_wrapped_aes_key, derived_key) && apple_des3_ede_unwrap_key1(cur_salt->wrapped_hmac_sha1_key, cur_salt->len_hmac_sha1_key, derived_key))
    {
      cracked[index + j] = 1;
    }

  }
  else
  {
    DES_key_schedule ks1;
    DES_key_schedule ks2;
    DES_key_schedule ks3;
    unsigned char TEMP1[sizeof(cur_salt->wrapped_hmac_sha1_key)];
    AES_KEY aes_decrypt_key;
    unsigned char outbuf[8192 + 1];
    unsigned char outbuf2[4096 + 1];
    unsigned char iv[20];
    const char nulls[8] = {0};
    unsigned char derived_key[32];
    const char *password = saved_key[index];
    pbkdf2_sha1((const unsigned char *) password, strlen(password), cur_salt->salt, 20, cur_salt->iterations, derived_key, 32, 0);
    j = 0;
    DES_set_key_unchecked((DES_cblock *) (derived_key + 0), &ks1);
    DES_set_key_unchecked((DES_cblock *) (derived_key + 8), &ks2);
    DES_set_key_unchecked((DES_cblock *) (derived_key + 16), &ks3);
    memcpy(iv, cur_salt->iv, 8);
    DES_ede3_cbc_encrypt(cur_salt->encrypted_keyblob, TEMP1, cur_salt->encrypted_keyblob_size, &ks1, &ks2, &ks3, (DES_cblock *) iv, 0);
    memcpy(aes_key_, TEMP1, 32);
    memcpy(hmacsha1_key_, TEMP1, 20);
    JTR_hmac_sha1(hmacsha1_key_, 20, (unsigned char *) (&cur_salt->cno), 4, iv, 20);
    if (cur_salt->encrypted_keyblob_size == 48)
      JTR_AES_set_decrypt_key(aes_key_, 128, &aes_decrypt_key);
    else
      JTR_AES_set_decrypt_key(aes_key_, 128 * 2, &aes_decrypt_key);

    JTR_AES_cbc_encrypt(cur_salt->chunk, outbuf, cur_salt->data_size, &aes_decrypt_key, iv, 0);
    if (jtr_memmem(outbuf, cur_salt->data_size, (void *) nulls, 8))
    {
      cracked[index + j] = 1;
    }

    if ((!cracked[index + j]) && (cur_salt->scp == 1))
    {
      int cno = 0;
      JTR_hmac_sha1(hmacsha1_key_, 20, (unsigned char *) (&cno), 4, iv, 20);
      if (cur_salt->encrypted_keyblob_size == 48)
        JTR_AES_set_decrypt_key(aes_key_, 128, &aes_decrypt_key);
      else
        JTR_AES_set_decrypt_key(aes_key_, 128 * 2, &aes_decrypt_key);

      JTR_AES_cbc_encrypt(cur_salt->zchunk, outbuf2, 4096, &aes_decrypt_key, iv, 0);
      if (jtr_memmem(outbuf2, 4096, (void *) nulls, 8))
      {
        cracked[index + j] = 1;
      }

    }

  }

  return;
}

