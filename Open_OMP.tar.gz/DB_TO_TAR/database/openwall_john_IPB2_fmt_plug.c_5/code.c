for (i = 0; i < 16; ++i)
{
  v = *(kh++);
  *(key_ptr++) = itoa16_shr_04[ARCH_INDEX(v)];
  *(key_ptr++) = itoa16_and_0f[ARCH_INDEX(v)];
}
