for (j = 0; j < 32; j++)
{
  client = &svs.clients[j];
  if (client->state < cs_connected)
    continue;

  if (client->state != cs_spawned)
    continue;

  SZ_Write(&client->datagram, sv.datagram.data, sv.datagram.cursize);
}
