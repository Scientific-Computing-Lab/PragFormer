for (i = 0; i < 16; i++)
  tmp[i] = (atoi16[ARCH_INDEX(pos[i * 2])] << 4) + atoi16[ARCH_INDEX(pos[(i * 2) + 1])];
