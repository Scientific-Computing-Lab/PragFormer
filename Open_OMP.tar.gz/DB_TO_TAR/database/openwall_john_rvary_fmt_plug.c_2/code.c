for (i = strlen((const char *) str); i < 9; ++i)
  str[i] = 0x40;
