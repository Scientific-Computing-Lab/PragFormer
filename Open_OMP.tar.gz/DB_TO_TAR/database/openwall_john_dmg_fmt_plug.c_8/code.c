for (i = 0; i < 4096; i++)
  cs.zchunk[i] = (atoi16[ARCH_INDEX(p[i * 2])] * 16) + atoi16[ARCH_INDEX(p[(i * 2) + 1])];
