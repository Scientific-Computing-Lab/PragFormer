for (i = 0; i < sc_threads; i++)
  free_region_t(&memory[i]);
