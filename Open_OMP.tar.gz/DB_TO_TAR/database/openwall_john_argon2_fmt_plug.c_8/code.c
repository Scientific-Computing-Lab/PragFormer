for (i = 0; i < count; i++)
{
  if (!memcmp(binary, crypted[i], saved_salt.hash_size))
    return 1;

}
