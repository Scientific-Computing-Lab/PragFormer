for (index = 0; index < count; index++)
{
  jtr_sha256_ctx ctx;
  jtr_sha256_init(&ctx, 1);
  jtr_sha256_update(&ctx, saved_key[index], saved_len[index]);
  jtr_sha256_update(&ctx, cur_salt, salt_len);
  jtr_sha256_final((unsigned char *) crypt_out[index], &ctx);
}
