for (index = 0; index < 16; index += 2)
{
  l = atoi16[ARCH_INDEX(ciphertext[index])];
  h = atoi16[ARCH_INDEX(ciphertext[index + 1])];
  value = DES_LM_reverse[l] | (DES_LM_reverse[h] << 4);
  block[index >> 3] |= value << ((index << 2) & 0x18);
}
