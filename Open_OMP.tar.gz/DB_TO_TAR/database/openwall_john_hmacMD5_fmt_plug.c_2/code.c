for (i = 0; i < len; i++)
{
  ipad[index][i] ^= k0[i];
  opad[index][i] ^= k0[i];
}
