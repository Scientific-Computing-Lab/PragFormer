for (i = 1; i < (51 - 1); ++i)
{
  ch = ciphertext[i];
  if (((!isalnum(ch)) && (ch != '+')) && (ch != '/'))
    return 0;

}
