for (y = 0; y < (1 * omp_para); y++)
  for (x = 0; x < 4; x++)
{
  if (((MD5_word *) binary)[0] == ((MD5_word *) sout)[x + ((y * 4) * 4)])
    return 1;

}

