for (p = (byte *) newcl->userinfo, q = (byte *) userinfo; (*q) && (p < ((((byte *) newcl->userinfo) + (sizeof(newcl->userinfo))) - 1)); q++)
  if (((*q) > 31) && ((*q) <= 127))
  *(p++) = *q;

