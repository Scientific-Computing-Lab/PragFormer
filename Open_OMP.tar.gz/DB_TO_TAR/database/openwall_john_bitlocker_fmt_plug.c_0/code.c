for (index = 0; index < count; index += 1)
{
  unsigned char *passwordBuf;
  int passwordBufSize;
  int i;
  unsigned char out[1][32];
  jtr_sha256_ctx ctx;
  unsigned char output[256] = {0};
  uint32_t data_size = 0;
  uint32_t version = 0;
  unsigned char *vmk_blob = 0;
  unsigned char v1;
  unsigned char v2;
  for (i = 0; i < 1; ++i)
  {
    passwordBuf = (unsigned char *) saved_key[index + i];
    passwordBufSize = strlen16((UTF16 *) passwordBuf) * 2;
    jtr_sha256_init(&ctx, 1);
    jtr_sha256_update(&ctx, passwordBuf, passwordBufSize);
    jtr_sha256_final(out[i], &ctx);
    jtr_sha256_init(&ctx, 1);
    jtr_sha256_update(&ctx, out[i], 32);
    jtr_sha256_final(out[i], &ctx);
    bitlocker_kdf(out[i], out[i]);
    libcaes_crypt_ccm(out[i], 256, 0, cur_salt->iv, 12, cur_salt->data, cur_salt->data_size, output, cur_salt->data_size);
    version = output[20] | (output[21] << 8);
    data_size = output[16] | (output[17] << 8);
    vmk_blob = &output[16];
    v1 = vmk_blob[8];
    v2 = vmk_blob[9];
    if ((((version == 1) && (data_size == 0x2c)) && (v1 <= 0x05)) && (v2 == 0x20))
      cracked[index + i] = 1;
    else
    {
      cracked[index + i] = 0;
    }

  }

}

static void bitlocker_kdf(unsigned char *password_hash, unsigned char *out)
{
  struct libbde_password_key_data pkd;
  jtr_sha256_ctx ctx;
  uint64_t ic;
  memset(&pkd, 0, sizeof(struct libbde_password_key_data));
  memcpy(pkd.initial_sha256_hash, password_hash, 32);
  memcpy(pkd.salt, cur_salt->salt, cur_salt->salt_length);
  for (ic = 0; ic < cur_salt->iterations; ic++)
  {
    jtr_sha256_init(&ctx, 1);
    pkd.iteration_count = __builtin_bswap64(ic);
    jtr_sha256_update(&ctx, &pkd, sizeof(struct libbde_password_key_data));
    jtr_sha256_final(pkd.last_sha256_hash, &ctx);
  }

  memcpy(out, pkd.last_sha256_hash, 32);
}

