for (i = 1; i < m_ompt; ++i)
  dyna_eLargeOut[i] = what;
