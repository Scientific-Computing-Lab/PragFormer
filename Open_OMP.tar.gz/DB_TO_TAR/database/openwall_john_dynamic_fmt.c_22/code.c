for (i = 0; i < m_Dynamic_Count; ++i)
{
  if (Dynamic_curdat.store_keys_in_input)
  {
    dc.iPw = input_buf_X86[i >> MD5_X2].x1.b;
  }
  else
    dc.iPw = saved_key[i];

  dc.nPw = saved_key_len[i];
  dc.oBin = crypt_key_X86[i >> MD5_X2].x1.B;
  run_one_RDP_test(&dc);
}
