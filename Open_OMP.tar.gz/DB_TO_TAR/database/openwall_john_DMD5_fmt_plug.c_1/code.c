for (i = 0; i < 16; ++i)
  ((unsigned char *) out)[i] = (atoi16[ARCH_INDEX(response[i * 2])] << 4) + atoi16[ARCH_INDEX(response[(i * 2) + 1])];
