for (sound_num = 1; (sound_num < 256) && sv.sound_precache[sound_num]; sound_num++)
  if (!Q_strcmp(sample, sv.sound_precache[sound_num]))
  break;

