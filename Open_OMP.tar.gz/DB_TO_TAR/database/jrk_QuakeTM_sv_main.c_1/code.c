for (p = (unsigned char *) sys_text; *p; p++)
{
  *p &= 0x7f;
  if ((((((*p) > 128) || ((*p) < 32)) && ((*p) != 10)) && ((*p) != 13)) && ((*p) != 9))
    printf("[%02x]", *p);
  else
    putc(*p, stdout);

}
