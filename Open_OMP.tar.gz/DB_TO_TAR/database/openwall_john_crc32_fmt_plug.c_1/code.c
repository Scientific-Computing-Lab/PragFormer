for (i = 0; i < count; ++i)
{
  CRC32_t crc = crcsalt;
  unsigned char *p = (unsigned char *) saved_key[i];
  while (*p)
    crc = JTR_CRC32_tableC[(unsigned char) (crc ^ (*(p++)))] ^ (crc >> 8);

  crcs[i] = crc;
}
