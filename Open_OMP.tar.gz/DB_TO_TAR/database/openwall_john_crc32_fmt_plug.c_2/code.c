for (i = 0; i < 8; ++i)
{
  int c1 = ARCH_INDEX(p[1 + i]);
  int c2 = ARCH_INDEX(p[10 + i]);
  if ((atoi16[c1] == 0x7F) || (atoi16[c2] == 0x7F))
    return 0;

  if ((c1 >= 'A') && (c1 <= 'F'))
    return 0;

  if ((c2 >= 'A') && (c2 <= 'F'))
    return 0;

}
