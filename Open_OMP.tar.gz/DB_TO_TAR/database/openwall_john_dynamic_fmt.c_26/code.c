for (i = len - 3; i >= 0; --i)
{
  if ((extern_salt[i] == '$') && (extern_salt[i + 1] == '$'))
  {
    switch (extern_salt[i + 2])
    {
      case '2':
        if (Dynamic_curdat.b2Salts)
      {
        salt2 = &extern_salt[i + 3];
        nsalt2 = strlen((char *) salt2);
        nsalt2 = ConvertFromHex(salt2, nsalt2);
        extern_salt[i] = 0;
        bit_array |= 1;
        the_real_len += nsalt2 + 1;
      }

        break;

      case 'U':
        if (Dynamic_curdat.nUserName)
      {
        userid = &extern_salt[i + 3];
        nuserid = strlen((char *) userid);
        nuserid = ConvertFromHex(userid, nuserid);
        extern_salt[i] = 0;
        bit_array |= 2;
        the_real_len += nuserid + 1;
      }

        break;

      case 'F':
      {
        if ((extern_salt[i + 3] >= '0') && (extern_salt[i + 3] <= '9'))
        {
          if (Dynamic_curdat.FldMask && ((Dynamic_curdat.FldMask & (0x00008000 << (extern_salt[i + 3] - '0'))) == (0x00008000 << (extern_salt[i + 3] - '0'))))
          {
            Flds[extern_salt[i + 3] - '0'] = &extern_salt[i + 4];
            nFlds[extern_salt[i + 3] - '0'] = strlen((char *) Flds[extern_salt[i + 3] - '0']);
            nFlds[extern_salt[i + 3] - '0'] = ConvertFromHex(Flds[extern_salt[i + 3] - '0'], nFlds[extern_salt[i + 3] - '0']);
            extern_salt[i] = 0;
            bit_array |= 1 << ((2 + extern_salt[i + 3]) - '0');
            the_real_len += nFlds[extern_salt[i + 3] - '0'] + 1;
          }

          break;
        }

      }

    }

  }

}

static int ConvertFromHex(unsigned char *p, int len)
{
  unsigned char *cp;
  unsigned int i;
  unsigned int x;
  if ((!p) || memcmp(p, "HEX$", 4))
    return len;

  len -= 4;
  len >>= 1;
  cp = p;
  x = len;
  for (i = 4; x; --x, i += 2)
  {
    *(cp++) = (atoi16[ARCH_INDEX(p[i])] * 16) + atoi16[ARCH_INDEX(p[i + 1])];
  }

  *cp = 0;
  return len;
}


static int ConvertFromHex(unsigned char *p, int len)
{
  unsigned char *cp;
  unsigned int i;
  unsigned int x;
  if ((!p) || memcmp(p, "HEX$", 4))
    return len;

  len -= 4;
  len >>= 1;
  cp = p;
  x = len;
  for (i = 4; x; --x, i += 2)
  {
    *(cp++) = (atoi16[ARCH_INDEX(p[i])] * 16) + atoi16[ARCH_INDEX(p[i + 1])];
  }

  *cp = 0;
  return len;
}


static int ConvertFromHex(unsigned char *p, int len)
{
  unsigned char *cp;
  unsigned int i;
  unsigned int x;
  if ((!p) || memcmp(p, "HEX$", 4))
    return len;

  len -= 4;
  len >>= 1;
  cp = p;
  x = len;
  for (i = 4; x; --x, i += 2)
  {
    *(cp++) = (atoi16[ARCH_INDEX(p[i])] * 16) + atoi16[ARCH_INDEX(p[i + 1])];
  }

  *cp = 0;
  return len;
}

