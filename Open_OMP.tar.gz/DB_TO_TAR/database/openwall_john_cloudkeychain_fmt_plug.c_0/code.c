for (index = 0; index < count; index += 1)
{
  uint64_t key[8];
  pbkdf2_sha512((const unsigned char *) saved_key[index], strlen(saved_key[index]), cur_salt->salt, cur_salt->saltlen, cur_salt->iterations, (unsigned char *) key, 64, 0);
  cracked[index] = ckcdecrypt((unsigned char *) key);
}

static void pbkdf2_sha512(const unsigned char *K, int KL, unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint64_t x64[64 / (sizeof(uint64_t))];
    unsigned char out[64];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  jtr_sha512_ctx ipad;
  jtr_sha512_ctx opad;
  _pbkdf2_sha512_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (64 - 1)) / 64;
  loop = (skip_bytes / 64) + 1;
  skip_bytes %= 64;
  while (loop <= loops)
  {
    _pbkdf2_sha512(S, SL, R, tmp.x64, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 64) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}


static int ckcdecrypt(unsigned char *key)
{
  unsigned char tmp[32];
  JTR_hmac_sha256(key + 32, 32, cur_salt->hmacdata, cur_salt->hmacdatalen, tmp, 32);
  if (!memcmp(tmp, cur_salt->expectedhmac, 16))
    return 1;
  else
    return 0;

}

