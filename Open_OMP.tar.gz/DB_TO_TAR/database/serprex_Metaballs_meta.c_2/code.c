for (int i = 0; i < 256; i++)
{
  col[i][0] = ((i * i) * i) >> 16;
  col[i][1] = (i * i) >> 8;
  col[i][2] = i;
}
