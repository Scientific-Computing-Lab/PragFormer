for (index = 0; index < count; index++)
{
  MD5_CTX ctx;
  unsigned char *out = (unsigned char *) crypt_out[index];
  unsigned char hash[16];
  john_MD5_Init(&ctx);
  john_MD5_Update(&ctx, saved_key[index], saved_len[index]);
  john_MD5_Final(hash, &ctx);
  compressor(hash, out);
}

static void compressor(unsigned char *in, unsigned char *out)
{
  int i;
  int j;
  for (i = 0, j = 0; i < 16; i += 2, j++)
  {
    out[j] = (in[i] + in[i + 1]) % 62;
    if (out[j] < 10)
    {
      out[j] += 48;
    }
    else
      if (out[j] < 36)
    {
      out[j] += 55;
    }
    else
    {
      out[j] += 61;
    }


  }

}

