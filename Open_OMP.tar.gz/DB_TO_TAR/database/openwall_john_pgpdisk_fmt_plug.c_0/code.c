for (index = 0; index < count; index++)
{
  unsigned char key[40];
  if (((cur_salt->algorithm == 5) || (cur_salt->algorithm == 6)) || (cur_salt->algorithm == 7))
  {
    AES_KEY aes_key;
    pgpdisk_kdf(saved_key[index], cur_salt->salt, key, 32);
    JTR_AES_set_encrypt_key(key, 256, &aes_key);
    (1 == 1) ? (JTR_AES_encrypt(key, (unsigned char *) crypt_out[index], &aes_key)) : (JTR_AES_decrypt(key, (unsigned char *) crypt_out[index], &aes_key));
  }
  else
    if (cur_salt->algorithm == 4)
  {
    Twofish_key tkey;
    pgpdisk_kdf(saved_key[index], cur_salt->salt, key, 32);
    Twofish_prepare_key(key, 32, &tkey);
    Twofish_encrypt(&tkey, key, (unsigned char *) crypt_out[index]);
  }
  else
    if (cur_salt->algorithm == 3)
  {
    CAST_KEY ck;
    pgpdisk_kdf(saved_key[index], cur_salt->salt, key, 16);
    CAST_set_key(&ck, 16, key);
    memset((unsigned char *) crypt_out[index], 0, 16);
    CAST_ecb_encrypt(key, (unsigned char *) crypt_out[index], &ck, 1);
  }



}

static void pgpdisk_kdf(char *password, unsigned char *salt, unsigned char *key, int key_length)
{
  uint32_t bytesNeeded = key_length;
  uint32_t offset = 0;
  unsigned char hash[20];
  int plen;
  int iterations = cur_salt->iterations;
  sph_sha1_context ctx;
  plen = strlen(password);
  while (bytesNeeded > 0)
  {
    uint32_t bytesThisTime = (20 < bytesNeeded) ? (20) : (bytesNeeded);
    uint32_t j = 0;
    sph_sha1_init(&ctx);
    if (offset > 0)
    {
      sph_sha1(&ctx, key, 20);
    }

    sph_sha1(&ctx, password, plen);
    sph_sha1_close(&ctx, hash);
    sph_sha1_init(&ctx);
    if (cur_salt->algorithm == 3)
      sph_sha1(&ctx, salt, 8);
    else
      sph_sha1(&ctx, salt, 16);

    for (j = 0; j < iterations; j++)
    {
      sph_sha1(&ctx, hash, bytesThisTime);
      sph_sha1(&ctx, ((uint8_t *) (&j)) + 3, 1);
    }

    sph_sha1_close(&ctx, key + offset);
    bytesNeeded -= bytesThisTime;
    offset += bytesThisTime;
  }

}


static void pgpdisk_kdf(char *password, unsigned char *salt, unsigned char *key, int key_length)
{
  uint32_t bytesNeeded = key_length;
  uint32_t offset = 0;
  unsigned char hash[20];
  int plen;
  int iterations = cur_salt->iterations;
  sph_sha1_context ctx;
  plen = strlen(password);
  while (bytesNeeded > 0)
  {
    uint32_t bytesThisTime = (20 < bytesNeeded) ? (20) : (bytesNeeded);
    uint32_t j = 0;
    sph_sha1_init(&ctx);
    if (offset > 0)
    {
      sph_sha1(&ctx, key, 20);
    }

    sph_sha1(&ctx, password, plen);
    sph_sha1_close(&ctx, hash);
    sph_sha1_init(&ctx);
    if (cur_salt->algorithm == 3)
      sph_sha1(&ctx, salt, 8);
    else
      sph_sha1(&ctx, salt, 16);

    for (j = 0; j < iterations; j++)
    {
      sph_sha1(&ctx, hash, bytesThisTime);
      sph_sha1(&ctx, ((uint8_t *) (&j)) + 3, 1);
    }

    sph_sha1_close(&ctx, key + offset);
    bytesNeeded -= bytesThisTime;
    offset += bytesThisTime;
  }

}


static void pgpdisk_kdf(char *password, unsigned char *salt, unsigned char *key, int key_length)
{
  uint32_t bytesNeeded = key_length;
  uint32_t offset = 0;
  unsigned char hash[20];
  int plen;
  int iterations = cur_salt->iterations;
  sph_sha1_context ctx;
  plen = strlen(password);
  while (bytesNeeded > 0)
  {
    uint32_t bytesThisTime = (20 < bytesNeeded) ? (20) : (bytesNeeded);
    uint32_t j = 0;
    sph_sha1_init(&ctx);
    if (offset > 0)
    {
      sph_sha1(&ctx, key, 20);
    }

    sph_sha1(&ctx, password, plen);
    sph_sha1_close(&ctx, hash);
    sph_sha1_init(&ctx);
    if (cur_salt->algorithm == 3)
      sph_sha1(&ctx, salt, 8);
    else
      sph_sha1(&ctx, salt, 16);

    for (j = 0; j < iterations; j++)
    {
      sph_sha1(&ctx, hash, bytesThisTime);
      sph_sha1(&ctx, ((uint8_t *) (&j)) + 3, 1);
    }

    sph_sha1_close(&ctx, key + offset);
    bytesNeeded -= bytesThisTime;
    offset += bytesThisTime;
  }

}

