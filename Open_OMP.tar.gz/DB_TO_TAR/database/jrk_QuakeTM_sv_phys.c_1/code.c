for (i = 0; i < 3; i++)
{
  if (((*((int *) (&ent->v.velocity[i]))) & nanmask) == nanmask)
  {
    Con_Printf("Got a NaN velocity on %s\n", PR_GetString(ent->v.classname));
    ent->v.velocity[i] = 0;
  }

  if (((*((int *) (&ent->v.origin[i]))) & nanmask) == nanmask)
  {
    Con_Printf("Got a NaN origin on %s\n", PR_GetString(ent->v.classname));
    ent->v.origin[i] = 0;
  }

  if (ent->v.velocity[i] > sv_maxvelocity.value)
    ent->v.velocity[i] = sv_maxvelocity.value;
  else
    if (ent->v.velocity[i] < (-sv_maxvelocity.value))
    ent->v.velocity[i] = -sv_maxvelocity.value;


}
