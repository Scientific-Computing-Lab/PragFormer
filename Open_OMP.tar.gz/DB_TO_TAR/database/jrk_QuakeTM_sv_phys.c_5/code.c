for (e = 1; e < sv.num_edicts; e++, check = (edict_t *) (((byte *) check) + pr_edict_size))
{
  if (check->free)
    continue;

  if (((check->v.movetype == 7) || (check->v.movetype == 0)) || (check->v.movetype == 8))
    continue;

  pusher->v.solid = 0;
  block = SV_TestEntityPosition(check);
  pusher->v.solid = 4;
  if (block)
    continue;

  if (!((((int) check->v.flags) & 512) && (((edict_t *) (((byte *) sv.edicts) + check->v.groundentity)) == pusher)))
  {
    if ((((((check->v.absmin[0] >= maxs[0]) || (check->v.absmin[1] >= maxs[1])) || (check->v.absmin[2] >= maxs[2])) || (check->v.absmax[0] <= mins[0])) || (check->v.absmax[1] <= mins[1])) || (check->v.absmax[2] <= mins[2]))
      continue;

    if (!SV_TestEntityPosition(check))
      continue;

  }

  {
    moved_from[num_moved][0] = check->v.origin[0];
    moved_from[num_moved][1] = check->v.origin[1];
    moved_from[num_moved][2] = check->v.origin[2];
  }
  ;
  moved_edict[num_moved] = check;
  num_moved++;
  {
    check->v.origin[0] = check->v.origin[0] + move[0];
    check->v.origin[1] = check->v.origin[1] + move[1];
    check->v.origin[2] = check->v.origin[2] + move[2];
  }
  ;
  block = SV_TestEntityPosition(check);
  if (!block)
  {
    SV_LinkEdict(check, false);
    continue;
  }

  {
    check->v.origin[0] = check->v.origin[0] - move[0];
    check->v.origin[1] = check->v.origin[1] - move[1];
    check->v.origin[2] = check->v.origin[2] - move[2];
  }
  ;
  block = SV_TestEntityPosition(check);
  if (!block)
  {
    num_moved--;
    continue;
  }

  if (check->v.mins[0] == check->v.maxs[0])
  {
    SV_LinkEdict(check, false);
    continue;
  }

  if ((check->v.solid == 0) || (check->v.solid == 1))
  {
    check->v.mins[0] = (check->v.mins[1] = 0);
    {
      check->v.maxs[0] = check->v.mins[0];
      check->v.maxs[1] = check->v.mins[1];
      check->v.maxs[2] = check->v.mins[2];
    }
    ;
    SV_LinkEdict(check, false);
    continue;
  }

  {
    pusher->v.origin[0] = pushorig[0];
    pusher->v.origin[1] = pushorig[1];
    pusher->v.origin[2] = pushorig[2];
  }
  ;
  SV_LinkEdict(pusher, false);
  if (pusher->v.blocked)
  {
    pr_global_struct->self = ((byte *) pusher) - ((byte *) sv.edicts);
    pr_global_struct->other = ((byte *) check) - ((byte *) sv.edicts);
    PR_ExecuteProgram(pusher->v.blocked);
  }

  for (i = 0; i < num_moved; i++)
  {
    {
      moved_edict[i]->v.origin[0] = moved_from[i][0];
      moved_edict[i]->v.origin[1] = moved_from[i][1];
      moved_edict[i]->v.origin[2] = moved_from[i][2];
    }
    ;
    SV_LinkEdict(moved_edict[i], false);
  }

  return false;
}
