for (i = 0; i < 32; i++)
  if (stats[i] != client->stats[i])
{
  client->stats[i] = stats[i];
  if ((stats[i] >= 0) && (stats[i] <= 255))
  {
    ClientReliableWrite_Begin(client, 3, 3);
    ClientReliableWrite_Byte(client, i);
    ClientReliableWrite_Byte(client, stats[i]);
  }
  else
  {
    ClientReliableWrite_Begin(client, 38, 6);
    ClientReliableWrite_Byte(client, i);
    ClientReliableWrite_Long(client, stats[i]);
  }

}

