for (index = 0; index < count; index += 1)
{
  unsigned char master[32];
  pbkdf2_sha1((unsigned char *) saved_key[index], strlen(saved_key[index]), cur_salt->data, 16, cur_salt->iter, master, 32, 0);
  if (blockchain_decrypt(master, cur_salt->data) == 0)
    cracked[index] = 1;
  else
    cracked[index] = 0;

}

static void pbkdf2_sha1(const unsigned char *K, int KL, const unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[20 / (sizeof(uint32_t))];
    unsigned char out[20];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  sph_sha1_context ipad;
  sph_sha1_context opad;
  _pbkdf2_sha1_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (20 - 1)) / 20;
  loop = (skip_bytes / 20) + 1;
  skip_bytes %= 20;
  while (loop <= loops)
  {
    _pbkdf2_sha1(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 20) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}

