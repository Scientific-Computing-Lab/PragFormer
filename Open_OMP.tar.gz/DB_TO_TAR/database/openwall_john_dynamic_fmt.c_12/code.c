for (i = 0; i < 4; ++i)
  dynamic_BHO[i].dat = mem_calloc_align(((1 << MD5_X2) * 2) * 2, sizeof(*dynamic_BHO[0].dat), 16);
