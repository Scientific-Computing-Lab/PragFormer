for (i = 0; i < 256; ++i)
{
  sprintf(buf, "%X%X", i >> 4, i & 0xF);
  memcpy(&__Dynamic_itoa_w2_u[i], buf, 2);
  sprintf(buf, "%x%x", i >> 4, i & 0xF);
  memcpy(&__Dynamic_itoa_w2_l[i], buf, 2);
}
