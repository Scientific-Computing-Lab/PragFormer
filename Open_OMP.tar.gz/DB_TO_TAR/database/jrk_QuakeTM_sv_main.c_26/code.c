for (i = 0; i < 8; i++)
  if (master_adr[i].port)
{
  Con_Printf("Sending heartbeat to %s\n", NET_AdrToString(master_adr[i]));
  NET_SendPacket(strlen(string), string, master_adr[i]);
}

