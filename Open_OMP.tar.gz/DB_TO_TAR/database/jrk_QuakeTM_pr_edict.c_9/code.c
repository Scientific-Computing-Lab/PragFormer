for (i = 1; i < progs->numfielddefs; i++)
{
  d = &pr_fielddefs[i];
  name = PR_GetString(d->s_name);
  if (name[Q_strlen(name) - 2] == '_')
    continue;

  v = (int *) (((char *) (&ed->v)) + (d->ofs * 4));
  type = d->type & (~(1 << 15));
  for (j = 0; j < type_size[type]; j++)
    if (v[j])
    break;


  if (j == type_size[type])
    continue;

  Con_Printf("%s", name);
  l = Q_strlen(name);
  while ((l++) < 15)
    Con_Printf(" ");

  Con_Printf("%s\n", PR_ValueString(d->type, (eval_t *) v));
}

char *PR_ValueString(unsigned short ddef_type, eval_t *val)
{
  static char line[256];
  ddef_t *def;
  dfunction_t *f;
  etype_t type;
  ddef_type &= ~(1 << 15);
  type = (etype_t) ddef_type;
  switch (type)
  {
    case ev_string:
      Q_sprintf(line, "%s", PR_GetString(val->string));
      break;

    case ev_entity:
      Q_sprintf(line, "entity %i", NUM_FOR_EDICT((edict_t *) (((byte *) sv.edicts) + val->edict)));
      break;

    case ev_function:
      f = pr_functions + val->function;
      Q_sprintf(line, "%s()", PR_GetString(f->s_name));
      break;

    case ev_field:
      def = ED_FieldAtOfs(val->_int);
      Q_sprintf(line, ".%s", PR_GetString(def->s_name));
      break;

    case ev_void:
      Q_sprintf(line, "void");
      break;

    case ev_float:
      Q_sprintf(line, "%5.1f", val->_float);
      break;

    case ev_vector:
      Q_sprintf(line, "'%5.1f %5.1f %5.1f'", val->vector[0], val->vector[1], val->vector[2]);
      break;

    case ev_pointer:
      Q_sprintf(line, "pointer");
      break;

    default:
      Q_sprintf(line, "bad type %d", (short) type);
      break;

  }

  return line;
}

