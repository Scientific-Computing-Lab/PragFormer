for (i = 0; i < 3; i++)
  MSG_WriteCoord(msg, other->v.origin[i] + (0.5 * (other->v.mins[i] + other->v.maxs[i])));
