for (i = 0; i < 8; i++)
  if (!isalnum((int) ((unsigned char) p[i])))
  return 0;

