for (i = 0; i < progs->numglobaldefs; i++)
{
  def = &pr_globaldefs[i];
  if (def->ofs == ofs)
    return def;

}
