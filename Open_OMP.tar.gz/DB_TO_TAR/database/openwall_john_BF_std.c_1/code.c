for (i = 0; i < (16 + 2); i++)
{
  tmp = 0;
  for (j = 0; j < 4; j++)
  {
    tmp <<= 8;
    if (sign_extension_bug)
      tmp |= (int) ((signed char) (*ptr));
    else
      tmp |= (unsigned char) (*ptr);

    if (!(*ptr))
      ptr = key;
    else
      ptr++;

  }

  BF_exp_key[index][i] = tmp;
  BF_init_key[index][i] = BF_init_state.P[i] ^ tmp;
}
