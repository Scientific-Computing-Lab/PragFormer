for (i = 0; i < (((1 << MD5_X2) * 2) * 2); ++i)
  total_len2_X86[i] = 32;
