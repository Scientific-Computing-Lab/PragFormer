for (index = 0; index < count; index++)
{
  int t = omp_get_thread_num();
  if (t >= max_threads)
  {
    failed = -1;
    continue;
  }

  uint8_t *hash;
  hash = yescrypt_r(0, &local[t], (const uint8_t *) buffer[index].key, strlen(buffer[index].key), (const uint8_t *) saved_salt, 0, (uint8_t *) buffer[index].out, sizeof(buffer[index].out));
  if (!hash)
  {
    failed = (errno) ? (errno) : (EINVAL);
  }

}
