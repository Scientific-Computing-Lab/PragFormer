for (index = 0; index < (threads * 1); index++)
  memcpy(saved_key[index], salt, 16 * 2);
