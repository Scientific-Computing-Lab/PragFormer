for (i = 0; i < 2; i++)
{
  if (!Q_strcmp(field, gefvCache[i].field))
  {
    def = gefvCache[i].pcache;
    goto Done;
  }

}
