for (i = 0; i < ((sizeof(*progs)) / 4); i++)
  ((int *) progs)[i] = LittleLong(((int *) progs)[i]);
