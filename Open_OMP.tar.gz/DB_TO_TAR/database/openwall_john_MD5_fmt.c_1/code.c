for (i = 0; i <= 6; i += 2)
{
  h = (unsigned char) atoi64[ARCH_INDEX(((char *) salt)[i])];
  h ^= ((unsigned char *) salt)[i + 1];
  h <<= 6;
  h ^= (unsigned char) atoi64[ARCH_INDEX(((char *) salt)[i + 1])];
  h ^= ((unsigned char *) salt)[i];
  retval += h;
}
