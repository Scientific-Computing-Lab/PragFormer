for (i = 0; i < len; ++i)
  crc = JTR_CRC32_table[(unsigned char) (crc ^ salt[i])] ^ (crc >> 8);
