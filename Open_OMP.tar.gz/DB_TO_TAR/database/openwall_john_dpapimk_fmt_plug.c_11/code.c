for (i = 0; i < cs.encrypted_len; i++)
  cs.encrypted[i] = (atoi16[ARCH_INDEX(p[i * 2])] * 16) + atoi16[ARCH_INDEX(p[(i * 2) + 1])];
