for (i = 0; i < numipfilters; i++)
  if (ipfilters[i].compare == 0xffffffff)
  break;

