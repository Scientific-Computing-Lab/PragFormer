for (index = 0; index < count; index++)
{
  if (new_keys)
    sevenzip_kdf(index, master[index]);

  cracked[index] = sevenzip_decrypt(master[index]);
}

static void sevenzip_kdf(int index, unsigned char *master)
{
  long long rounds = ((long long) 1) << sevenzip_salt->NumCyclesPower;
  long long round;
  int i;
  unsigned char temp[8] = {0, 0, 0, 0, 0, 0, 0, 0};
  jtr_sha256_ctx sha;
  jtr_sha256_init(&sha, 1);
  for (round = 0; round < rounds; round++)
  {
    if (sevenzip_salt->SaltSize)
      jtr_sha256_update(&sha, sevenzip_salt->salt, sevenzip_salt->SaltSize);

    jtr_sha256_update(&sha, (char *) saved_key[index], saved_len[index]);
    jtr_sha256_update(&sha, temp, 8);
    for (i = 0; i < 8; i++)
      if ((++temp[i]) != 0)
      break;


  }

  jtr_sha256_final(master, &sha);
}

