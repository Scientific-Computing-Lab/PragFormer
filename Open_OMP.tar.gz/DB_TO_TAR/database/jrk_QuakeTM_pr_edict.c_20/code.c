for (i = 0; i < progs->numfielddefs; i++)
{
  pr_fielddefs[i].type = LittleShort(pr_fielddefs[i].type);
  if (pr_fielddefs[i].type & (1 << 15))
    SV_Error("PR_LoadProgs: pr_fielddefs[i].type & DEF_SAVEGLOBAL");

  pr_fielddefs[i].ofs = LittleShort(pr_fielddefs[i].ofs);
  pr_fielddefs[i].s_name = LittleLong(pr_fielddefs[i].s_name);
}
