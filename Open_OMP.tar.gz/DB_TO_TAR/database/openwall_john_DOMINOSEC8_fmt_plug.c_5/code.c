for (; j > 16; j--)
{
  t = block[(p - x.c) - 16] ^ lotus_magic_table[j + t];
  *(p++) = t;
}
