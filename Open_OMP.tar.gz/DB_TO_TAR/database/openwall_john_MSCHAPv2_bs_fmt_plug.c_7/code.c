for (chr = 0; chr < 24; chr = chr + 8)
{
  dst = 0;
  for (i = 0; i < 8; i++)
  {
    value = binary[chr + i];
    mask = 0x80;
    for (src = 0; src < 8; src++)
    {
      if (value & mask)
        block[(chr / 4) + (dst >> 5)] |= 1U << (dst & 0x1F);

      mask >>= 1;
      dst++;
    }

  }

}
