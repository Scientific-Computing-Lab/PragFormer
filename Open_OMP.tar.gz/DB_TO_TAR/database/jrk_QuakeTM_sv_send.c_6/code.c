for (i = 0; i < 3; i++)
  origin[i] = entity->v.origin[i] + (0.5 * (entity->v.mins[i] + entity->v.maxs[i]));
