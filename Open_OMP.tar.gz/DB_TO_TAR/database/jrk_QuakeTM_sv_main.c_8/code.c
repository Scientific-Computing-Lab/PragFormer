for (i = 0, cl = svs.clients; i < 32; i++, cl++)
{
  if (cl->state == cs_free)
    continue;

  if (NET_CompareBaseAdr(adr, cl->netchan.remote_address) && ((cl->netchan.qport == qport) || (adr.port == cl->netchan.remote_address.port)))
  {
    if (cl->state == cs_connected)
    {
      Con_Printf("%s:dup connect\n", NET_AdrToString(adr));
      userid--;
      return;
    }

    Con_Printf("%s:reconnect\n", NET_AdrToString(adr));
    SV_DropClient(cl);
    break;
  }

}

void SV_DropClient(client_t *drop)
{
  do
  {
    {
      MSG_WriteByte(&drop->netchan.message, 2);
    }
  }
  while (0);
  ;
  if (drop->state == cs_spawned)
  {
    if (!drop->spectator)
    {
      pr_global_struct->self = ((byte *) drop->edict) - ((byte *) sv.edicts);
      PR_ExecuteProgram(pr_global_struct->ClientDisconnect);
    }
    else
      if (SpectatorDisconnect)
    {
      pr_global_struct->self = ((byte *) drop->edict) - ((byte *) sv.edicts);
      PR_ExecuteProgram(SpectatorDisconnect);
    }


  }

  if (drop->spectator)
    Con_Printf("Spectator %s removed\n", drop->name);
  else
    Con_Printf("Client %s removed\n", drop->name);

  if (drop->download)
  {
    TM_fclose(drop->download);
    drop->download = 0;
  }

  if (drop->upload)
  {
    TM_fclose(drop->upload);
    drop->upload = 0;
  }

  *drop->uploadfn = 0;
  drop->state = cs_zombie;
  drop->connection_started = realtime;
  drop->old_frags = 0;
  drop->edict->v.frags = 0;
  drop->name[0] = 0;
  Q_memset(drop->userinfo, 0, sizeof(drop->userinfo));
  do
  {
    {
      do
      {
        {
          SV_FullClientUpdate(drop, &sv.reliable_datagram);
        }
      }
      while (0);
      ;
    }
  }
  while (0);
  ;
}

