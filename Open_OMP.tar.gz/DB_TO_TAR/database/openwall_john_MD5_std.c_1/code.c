for (t = 0; t < (MD5_std_nt * (((sizeof(MD5_std_combined)) + (64 - 1)) & (~(64 - 1)))); t += ((sizeof(MD5_std_combined)) + (64 - 1)) & (~(64 - 1)))
{
  (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t))).data = MD5_data_init;
  current = (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._pool;
  for (index = 0; index < (1 * 4); index++)
  {
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[0][index].even = &current->e.p;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[0][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[1][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[1][index].odd = &current->o.pp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[2][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[2][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[3][index].even = &current->e.pp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[3][index].odd = &current->o.ps;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[4][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[4][index].odd = &current->o.pp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[5][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[5][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[6][index].even = &current->e.pp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[6][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[7][index].even = &current->e.sp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[7][index].odd = &current->o.pp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[8][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[8][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[9][index].even = &current->e.pp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[9][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[10][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[10][index].odd = &current->o.p;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[11][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[11][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[12][index].even = &current->e.pp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[12][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[13][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[13][index].odd = &current->o.pp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[14][index].even = &current->e.sp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[14][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[15][index].even = &current->e.pp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[15][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[16][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[16][index].odd = &current->o.pp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[17][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[17][index].odd = &current->o.ps;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[18][index].even = &current->e.pp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[18][index].odd = &current->o.psp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[19][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[19][index].odd = &current->o.pp;
    ;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[20][index].even = &current->e.spp;
    (*((MD5_std_combined *) (((char *) MD5_std_all_p) + t)))._order[20][index].odd = &current->o.psp;
    ;
    current++;
  }

}
