for (index = 0; index < count; index++)
{
  if (saved_key[index][0] != 0)
    blowfish_encrypt_pass(saved_key[index], (char *) crypt_out[index]);

}

static void blowfish_encrypt_pass(char *text, char *new)
{
  unsigned int left;
  unsigned int right;
  unsigned int bf_S[4][256];
  unsigned int bf_P[16 + 2];
  blowfish_init(bf_P, bf_S, (unsigned char *) text, strlen(text));
  left = 0xdeadd061;
  right = 0x23f6b095;
  blowfish_encipher(bf_P, bf_S, &left, &right);
  left = __builtin_bswap32(left);
  right = __builtin_bswap32(right);
  memcpy(new, (unsigned char *) (&right), 32 / 8);
  memcpy(new + (32 / 8), (unsigned char *) (&left), (32 / 8) - 1);
}

