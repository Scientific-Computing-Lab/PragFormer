for (; i < 20; i++)
  Q_strcat(line, " ");
