for (index = 0; index < count; index += inc)
{
  int j = index;
  while (j < (index + inc))
  {
    if (cur_salt->type == 1)
    {
      pbkdf2_sha1((const unsigned char *) saved_key[j], strlen(saved_key[j]), cur_salt->salt, strlen((char *) cur_salt->salt), cur_salt->iterations, (unsigned char *) crypt_out[j], 20, 0);
      ++j;
    }
    else
      if (cur_salt->type == 256)
    {
      pbkdf2_sha256((const unsigned char *) saved_key[j], strlen(saved_key[j]), cur_salt->salt, strlen((char *) cur_salt->salt), cur_salt->iterations, (unsigned char *) crypt_out[j], 20, 0);
      ++j;
    }
    else
    {
      pbkdf2_sha512((const unsigned char *) saved_key[j], strlen(saved_key[j]), cur_salt->salt, strlen((char *) cur_salt->salt), cur_salt->iterations, (unsigned char *) crypt_out[j], 20, 0);
      ++j;
    }


  }

}

static void pbkdf2_sha1(const unsigned char *K, int KL, const unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[20 / (sizeof(uint32_t))];
    unsigned char out[20];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  sph_sha1_context ipad;
  sph_sha1_context opad;
  _pbkdf2_sha1_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (20 - 1)) / 20;
  loop = (skip_bytes / 20) + 1;
  skip_bytes %= 20;
  while (loop <= loops)
  {
    _pbkdf2_sha1(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 20) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}


static void pbkdf2_sha256(const unsigned char *K, int KL, unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[32 / (sizeof(uint32_t))];
    unsigned char out[32];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  jtr_sha256_ctx ipad;
  jtr_sha256_ctx opad;
  _pbkdf2_sha256_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (32 - 1)) / 32;
  loop = (skip_bytes / 32) + 1;
  skip_bytes %= 32;
  while (loop <= loops)
  {
    _pbkdf2_sha256(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 32) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}


static void pbkdf2_sha512(const unsigned char *K, int KL, unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint64_t x64[64 / (sizeof(uint64_t))];
    unsigned char out[64];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  jtr_sha512_ctx ipad;
  jtr_sha512_ctx opad;
  _pbkdf2_sha512_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (64 - 1)) / 64;
  loop = (skip_bytes / 64) + 1;
  skip_bytes %= 64;
  while (loop <= loops)
  {
    _pbkdf2_sha512(S, SL, R, tmp.x64, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 64) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}

