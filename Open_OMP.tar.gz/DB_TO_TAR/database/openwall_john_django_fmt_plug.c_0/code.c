for (index = 0; index < count; index += 1)
{
  pbkdf2_sha256((unsigned char *) saved_key[index], strlen(saved_key[index]), cur_salt->salt.c, strlen((char *) cur_salt->salt.c), cur_salt->iterations, (unsigned char *) crypt_out[index], 32, 0);
}

static void pbkdf2_sha256(const unsigned char *K, int KL, unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[32 / (sizeof(uint32_t))];
    unsigned char out[32];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  jtr_sha256_ctx ipad;
  jtr_sha256_ctx opad;
  _pbkdf2_sha256_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (32 - 1)) / 32;
  loop = (skip_bytes / 32) + 1;
  skip_bytes %= 32;
  while (loop <= loops)
  {
    _pbkdf2_sha256(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 32) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}

