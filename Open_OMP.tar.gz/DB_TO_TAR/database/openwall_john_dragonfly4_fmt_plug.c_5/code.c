for (index = 0; index < count; index++)
  if (!memcmp(binary, crypt_out[index], 62))
  return 1;

