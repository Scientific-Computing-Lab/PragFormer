for (i = 0; tests[i].ciphertext; i++)
{
  struct argon2_salt *salt;
  salt = get_salt(tests[i].ciphertext);
  m_cost = (m_cost > salt->m_cost) ? (m_cost) : (salt->m_cost);
  if (i == 0)
  {
    printf("\n");
    prev_m_cost = m_cost;
    print_memory((sizeof(block)) * m_cost);
  }

}

static void *get_salt(char *ciphertext)
{
  static struct argon2_salt salt;
  argon2_context ctx;
  memset(&salt, 0, sizeof(salt));
  ctx_init(&ctx);
  if (!strncmp(ciphertext, "$argon2d$", (sizeof("$argon2d$")) - 1))
  {
    argon2_decode_string(&ctx, ciphertext, Argon2_d);
    salt.type = Argon2_d;
  }
  else
  {
    argon2_decode_string(&ctx, ciphertext, Argon2_i);
    salt.type = Argon2_i;
  }

  salt.salt_length = ctx.saltlen;
  salt.m_cost = ctx.m_cost;
  salt.t_cost = ctx.t_cost;
  salt.lanes = ctx.lanes;
  salt.hash_size = ctx.outlen;
  memcpy(salt.salt, ctx.salt, ctx.saltlen);
  return (void *) (&salt);
}


static void print_memory(double memory)
{
  char s[] = "\0kMGT";
  int i = 0;
  while ((memory >= 1024) && s[i + 1])
  {
    memory /= 1024;
    i++;
  }

  fprintf(stderr, "memory per hash : %.2lf %cB\n", memory, s[i]);
}

