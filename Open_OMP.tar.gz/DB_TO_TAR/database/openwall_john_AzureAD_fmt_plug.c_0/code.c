for (index = 0; index < count; index += 1)
{
  UTF16 Buf[125 + 1];
  unsigned char hash[16];
  unsigned char hex[33];
  int len;
  int cnt;
  int i;
  MD4_CTX ctx;
  cnt = 1;
  if (dirty)
    for (i = 0; i < cnt; ++i)
  {
    len = enc_to_utf16(Buf, 125, (UTF8 *) saved_key[index + i], strlen(saved_key[index + i]));
    if (len < 0)
      len = 0;

    john_MD4_Init(&ctx);
    john_MD4_Update(&ctx, Buf, len * 2);
    john_MD4_Final(hash, &ctx);
    base64_convert(hash, e_b64_raw, 16, hex, e_b64_hex, sizeof(hex), 0x01, 0);
    for (len = 0; len < 32; ++len)
      saved_nt[index + i][len << 1] = hex[len];

  }


  pbkdf2_sha256((unsigned char *) saved_nt[index], 64, AzureAD_cur_salt->salt, AzureAD_cur_salt->salt_len, AzureAD_cur_salt->iterations, (unsigned char *) crypt_out[index], 32, 0);
}

static void pbkdf2_sha256(const unsigned char *K, int KL, unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[32 / (sizeof(uint32_t))];
    unsigned char out[32];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  jtr_sha256_ctx ipad;
  jtr_sha256_ctx opad;
  _pbkdf2_sha256_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (32 - 1)) / 32;
  loop = (skip_bytes / 32) + 1;
  skip_bytes %= 32;
  while (loop <= loops)
  {
    _pbkdf2_sha256(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 32) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}

