for (i = 0; i < 4; ++i)
{
  if (dynamic_BHO[i].dat)
  {
    free(dynamic_BHO[i].dat);
    dynamic_BHO[i].dat = 0;
  }

}
