for (i = 0; i < numipfilters; i++)
  if ((ipfilters[i].mask == f.mask) && (ipfilters[i].compare == f.compare))
{
  for (j = i + 1; j < numipfilters; j++)
    ipfilters[j - 1] = ipfilters[j];

  numipfilters--;
  Con_Printf("Removed.\n");
  return;
}

