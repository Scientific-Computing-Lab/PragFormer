for (i = 0; i < sc_threads; i++)
  alloc_region_t(&memory[i], mem_size);
