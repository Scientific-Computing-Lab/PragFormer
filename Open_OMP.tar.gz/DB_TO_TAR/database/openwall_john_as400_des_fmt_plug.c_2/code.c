for (i = strlen((const char *) str); i < 8; ++i)
  str[i] = 0x40;
