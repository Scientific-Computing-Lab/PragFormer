for (index = 0; index < count; index += 1)
{
  unsigned char key[1][32];
  unsigned char hash[1][32];
  BF_KEY bf_key;
  int bf_ivec_pos;
  int i;
  unsigned char ivec[8];
  unsigned char output[1024];
  sph_sha1_context ctx;
  if ((cur_salt->checksum_type == 0) && (cur_salt->cipher_type == 0))
  {
    for (i = 0; i < 1; ++i)
    {
      sph_sha1_init(&ctx);
      sph_sha1(&ctx, (unsigned char *) saved_key[index + i], strlen(saved_key[index + i]));
      sph_sha1_close(&ctx, (unsigned char *) hash[i]);
    }

    pbkdf2_sha1(hash[0], 20, cur_salt->salt, cur_salt->salt_length, cur_salt->iterations, key[0], cur_salt->key_size, 0);
    for (i = 0; i < 1; ++i)
    {
      unsigned int crypt[5];
      bf_ivec_pos = 0;
      memcpy(ivec, cur_salt->iv, 8);
      BF_set_key(&bf_key, cur_salt->key_size, key[i]);
      BF_cfb64_encrypt(cur_salt->content, output, cur_salt->content_length, &bf_key, ivec, &bf_ivec_pos, 0);
      sph_sha1_init(&ctx);
      sph_sha1(&ctx, output, cur_salt->original_length);
      sph_sha1_close(&ctx, (unsigned char *) crypt);
      crypt_out[index + i][0] = crypt[0];
      if (((cur_salt->original_length % 64) >= 52) && ((cur_salt->original_length % 64) <= 55))
        SHA1_odf_buggy(output, cur_salt->original_length, crypt);

      crypt_out[index + i][1] = crypt[0];
    }

  }
  else
  {
    jtr_sha256_ctx ctx;
    AES_KEY akey;
    unsigned char iv[16];
    for (i = 0; i < 1; ++i)
    {
      jtr_sha256_init(&ctx, 1);
      jtr_sha256_update(&ctx, (unsigned char *) saved_key[index + i], strlen(saved_key[index + i]));
      jtr_sha256_final((unsigned char *) hash[i], &ctx);
    }

    pbkdf2_sha1(hash[0], 32, cur_salt->salt, cur_salt->salt_length, cur_salt->iterations, key[0], cur_salt->key_size, 0);
    for (i = 0; i < 1; ++i)
    {
      unsigned int crypt[8];
      memcpy(iv, cur_salt->iv, 16);
      JTR_AES_set_decrypt_key(key[i], 256, &akey);
      JTR_AES_cbc_encrypt(cur_salt->content, output, cur_salt->content_length, &akey, iv, 0);
      jtr_sha256_init(&ctx, 1);
      jtr_sha256_update(&ctx, output, cur_salt->content_length);
      jtr_sha256_final((unsigned char *) crypt, &ctx);
      crypt_out[index + i][0] = crypt[0];
      crypt_out[index + i][1] = crypt[0];
    }

  }

}

static void pbkdf2_sha1(const unsigned char *K, int KL, const unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[20 / (sizeof(uint32_t))];
    unsigned char out[20];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  sph_sha1_context ipad;
  sph_sha1_context opad;
  _pbkdf2_sha1_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (20 - 1)) / 20;
  loop = (skip_bytes / 20) + 1;
  skip_bytes %= 20;
  while (loop <= loops)
  {
    _pbkdf2_sha1(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 20) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}


static void pbkdf2_sha1(const unsigned char *K, int KL, const unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[20 / (sizeof(uint32_t))];
    unsigned char out[20];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  sph_sha1_context ipad;
  sph_sha1_context opad;
  _pbkdf2_sha1_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (20 - 1)) / 20;
  loop = (skip_bytes / 20) + 1;
  skip_bytes %= 20;
  while (loop <= loops)
  {
    _pbkdf2_sha1(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 20) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}

