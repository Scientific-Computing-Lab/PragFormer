for (i = 0; i < 4; i++)
{
  b[i] = 0;
  m[i] = 0;
}
