for (i = 0; i < ((len / 4) * 3); i += 3)
{
  value = ((((uint32_t) atoi64[ARCH_INDEX(pos[0])]) | (((uint32_t) atoi64[ARCH_INDEX(pos[1])]) << 6)) | (((uint32_t) atoi64[ARCH_INDEX(pos[2])]) << 12)) | (((uint32_t) atoi64[ARCH_INDEX(pos[3])]) << 18);
  pos += 4;
  out.c[i] = value >> 16;
  out.c[i + 1] = value >> 8;
  out.c[i + 2] = value;
}
