for (i = 0; i < sv.num_edicts; i++, ent = (edict_t *) (((byte *) ent) + pr_edict_size))
{
  if (ent->free)
    continue;

  SV_LinkEdict(ent, true);
  if ((i > 0) && (i <= 32))
    continue;

  SV_RunEntity(ent);
  SV_RunNewmis();
}

void SV_RunEntity(edict_t *ent)
{
  if (ent->v.lastruntime == ((float) realtime))
    return;

  ent->v.lastruntime = (float) realtime;
  switch ((int) ent->v.movetype)
  {
    case 7:
      SV_Physics_Pusher(ent);
      break;

    case 0:
      SV_Physics_None(ent);
      break;

    case 8:
      SV_Physics_Noclip(ent);
      break;

    case 4:
      SV_Physics_Step(ent);
      break;

    case 3:

    case 6:

    case 10:

    case 5:

    case 9:
      SV_Physics_Toss(ent);
      break;

    default:
      SV_Error("SV_Physics: bad movetype %i", (int) ent->v.movetype);

  }

}


void SV_RunNewmis(void)
{
  edict_t *ent;
  if (!pr_global_struct->newmis)
    return;

  ent = (edict_t *) (((byte *) sv.edicts) + pr_global_struct->newmis);
  host_frametime = 0.05;
  pr_global_struct->newmis = 0;
  SV_RunEntity(ent);
}

