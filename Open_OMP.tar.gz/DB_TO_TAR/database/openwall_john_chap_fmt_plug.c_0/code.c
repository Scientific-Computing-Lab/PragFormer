for (index = 0; index < count; index++)
{
  MD5_CTX ctx;
  john_MD5_Init(&ctx);
  john_MD5_Update(&ctx, &cur_salt->id, 1);
  john_MD5_Update(&ctx, saved_key[index], strlen(saved_key[index]));
  john_MD5_Update(&ctx, cur_salt->challenge, cur_salt->challenge_length);
  john_MD5_Final((unsigned char *) crypt_out[index], &ctx);
}
