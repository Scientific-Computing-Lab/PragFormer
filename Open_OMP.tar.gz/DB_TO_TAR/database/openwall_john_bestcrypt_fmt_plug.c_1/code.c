for (i = 0; (i < cs.salt_size) && p[2 * i]; i++)
  cs.salt[i] = (atoi16[ARCH_INDEX(p[2 * i])] << 4) | atoi16[ARCH_INDEX(p[(2 * i) + 1])];
