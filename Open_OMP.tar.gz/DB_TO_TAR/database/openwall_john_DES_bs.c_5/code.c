for (bit = 0; bit < count; bit++)
  if (((((unsigned int) (*((unsigned char *) (&b[bit])))) >> index) ^ (binary[1] >> bit)) & 1)
  return 0;

