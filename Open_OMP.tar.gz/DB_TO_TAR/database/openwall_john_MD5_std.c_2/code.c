for (length = 0; (length < 8) && salt[length]; length++)
  ;
