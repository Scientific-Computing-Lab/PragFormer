for (int i = 0; i < (ms - 1); i++)
{
  float h = ((X[i] - X[ms - 1]) * (X[i] - X[ms - 1])) + ((Y[i] - Y[ms - 1]) * (Y[i] - Y[ms - 1]));
  if (h < d)
  {
    c = i;
    d = h;
  }

}
