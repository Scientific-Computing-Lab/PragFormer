for (i = 0; (i < (cs.active_slots * 256)) && p[2 * i]; i++)
  cs.key[i] = (atoi16[ARCH_INDEX(p[2 * i])] << 4) | atoi16[ARCH_INDEX(p[(2 * i) + 1])];
