for (i = 2; i < Cmd_Argc(); i++)
{
  strcat(remaining, Cmd_Argv(i));
  strcat(remaining, " ");
}
