for (i = 0; i < sc_threads; i++)
{
  init_region_t(&memory[i]);
  pseudo_rands[i] = 0;
}
