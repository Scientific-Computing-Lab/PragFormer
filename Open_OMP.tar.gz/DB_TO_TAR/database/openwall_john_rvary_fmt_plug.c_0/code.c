for (index = 0; index < count; index++)
{
  if (dirty)
  {
    DES_cblock des_key;
    int i;
    for (i = 0; saved_key[index][i]; i++)
      des_key[i] = a2e_precomputed[ARCH_INDEX(saved_key[index][i])];

    while (i < 8)
      des_key[i++] = 0x2a;

    DES_set_key_unchecked(&des_key, &schedules[index]);
  }

  char key[10];
  strnzcpy(key, saved_key[index], 9);
  ascii2ebcdic((unsigned char *) key);
  ebcdic_padding((unsigned char *) key);
  DES_ecb_encrypt((const_DES_cblock *) key, (DES_cblock *) crypt_out[index], &schedules[index], 1);
}

static void ascii2ebcdic(unsigned char *str)
{
  int i;
  int n = strlen((const char *) str);
  for (i = 0; i < n; ++i)
    str[i] = a2e[str[i]];

}


static void ebcdic_padding(unsigned char *str)
{
  int i;
  for (i = strlen((const char *) str); i < 9; ++i)
    str[i] = 0x40;

  str[9] = 0;
}

