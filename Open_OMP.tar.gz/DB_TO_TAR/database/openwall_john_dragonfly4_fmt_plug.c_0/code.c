for (index = 0; index < count; index++)
{
  jtr_sha512_ctx ctx;
  jtr_sha512_init(&ctx, 1);
  jtr_sha512_update(&ctx, saved_key[index], saved_len[index]);
  jtr_sha512_update(&ctx, cur_salt, salt_len);
  jtr_sha512_final((unsigned char *) crypt_out[index], &ctx);
}
