for (; j < til; ++j)
{
  unsigned int z;
  unsigned char *cp;
  unsigned char *cpi = (unsigned char *) utf16Str;
  if ((total_len2_X86[j] + outlen) <= (256 - 17))
  {
    cp = &input_buf2_X86[j >> MD5_X2].x1.B[total_len2_X86[j]];
    for (z = 0; z < outlen; ++z)
    {
      *(cp++) = *(cpi++);
    }

    total_len2_X86[j] += outlen;
  }

}
