for (i = 0; i < progs->numfielddefs; i++)
{
  def = &pr_fielddefs[i];
  if (def->ofs == ofs)
    return def;

}
