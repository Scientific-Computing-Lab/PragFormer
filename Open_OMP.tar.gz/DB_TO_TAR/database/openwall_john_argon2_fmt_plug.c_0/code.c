for (i = 0; i < count; i++)
{
  argon2_hash(saved_salt.t_cost, saved_salt.m_cost, saved_salt.lanes, saved_key[i], saved_len[i], saved_salt.salt, saved_salt.salt_length, crypted[i], saved_salt.hash_size, 0, 0, saved_salt.type, ARGON2_VERSION_NUMBER, memory[omp_get_thread_num() % sc_threads].aligned, pseudo_rands[omp_get_thread_num() % sc_threads]);
}
