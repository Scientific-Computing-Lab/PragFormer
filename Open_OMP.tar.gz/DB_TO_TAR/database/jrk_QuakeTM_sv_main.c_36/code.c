for (i = 0; i < NoThreads; i++)
{
  printf("\nThread %d\n------------------------\n\n", i);
  for (j = 0; j < (16 * 1); j++)
  {
    printf("%d:\t%d\n", j, checkpoint[i][j]);
  }

}
