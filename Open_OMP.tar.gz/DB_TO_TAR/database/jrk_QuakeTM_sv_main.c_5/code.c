for (i = 0; i < 1024; i++)
{
  if (NET_CompareBaseAdr(net_from, svs.challenges[i].adr))
    break;

  if (svs.challenges[i].time < oldestTime)
  {
    oldestTime = svs.challenges[i].time;
    oldest = i;
  }

}
