for (i = 0; i < NoThreads; i++)
{
  for (j = 0; j < 8; j++)
    msg_nest_level[j] = 0;

  for (j = 0; j < 32; j++)
    client_nest_level[j] = 0;

}
