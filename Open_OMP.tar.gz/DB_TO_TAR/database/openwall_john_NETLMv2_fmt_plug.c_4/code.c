for (; atoi16[ARCH_INDEX(*pos2)] != 0x7F; pos2++)
  ;
