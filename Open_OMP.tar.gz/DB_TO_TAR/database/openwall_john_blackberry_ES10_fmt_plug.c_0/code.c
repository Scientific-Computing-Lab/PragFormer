for (index = 0; index < count; index += 1)
{
  int j;
  jtr_sha512_ctx ctx;
  jtr_sha512_init(&ctx, 1);
  jtr_sha512_update(&ctx, saved_key[index], strlen(saved_key[index]));
  jtr_sha512_update(&ctx, cur_salt->salt, strlen((char *) cur_salt->salt));
  jtr_sha512_final((unsigned char *) crypt_out[index], &ctx);
  for (j = 0; j < 99; j++)
  {
    jtr_sha512_ctx ctx;
    jtr_sha512_init(&ctx, 1);
    jtr_sha512_update(&ctx, (unsigned char *) crypt_out[index], 64);
    jtr_sha512_final((unsigned char *) crypt_out[index], &ctx);
  }

}
