for (i = 0; i < slen; ++i)
{
  s2[i << 1] = Salt[i];
  s2[(i << 1) + 1] = 0;
}
