for (i = pPriv->dynamic_SALT_OFFSET + 4; ciphertext[i]; i++)
  if (atoi16[ARCH_INDEX(ciphertext[i])] == 0x7f)
  return 0;

