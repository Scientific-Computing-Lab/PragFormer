for (dst = 0; dst < 24; dst++)
{
  if ((new ^ old) & 1)
  {
    long *sp1;
    long *sp2;
    int src1 = dst;
    int src2 = dst + 24;
    if (new & 1)
    {
      src1 = src2;
      src2 = dst;
    }

    sp1 = (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).Ens[src1];
    sp2 = (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).Ens[src2];
    (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).E.E[dst] = (long *) sp1;
    (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).E.E[dst + 24] = (long *) sp2;
    (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).E.E[dst + 48] = (long *) (sp1 + 32);
    (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).E.E[dst + 72] = (long *) (sp2 + 32);
  }

  new >>= 1;
  old >>= 1;
  if (new == old)
    break;

}
