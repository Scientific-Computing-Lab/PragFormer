for (i = 0; i < count; ++i)
  if ((*((unsigned int *) binary)) == (*((unsigned int *) crypt_key[i])))
  return 1;

