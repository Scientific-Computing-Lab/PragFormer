for (; j < til; ++j)
{
  memcpy(&input_buf_X86[j >> MD5_X2].x1.b[total_len_X86[j]], Str, len);
  total_len_X86[j] += len;
}
