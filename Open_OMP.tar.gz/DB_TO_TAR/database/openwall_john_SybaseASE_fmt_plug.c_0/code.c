for (index = 0; index < count; index += 1)
{
  jtr_sha256_ctx ctx;
  if (dirty)
  {
    jtr_sha256_init(&prep_ctx[index], 1);
    jtr_sha256_update(&prep_ctx[index], prep_key[index], 510);
  }

  memcpy(&ctx, &prep_ctx[index], sizeof(ctx));
  jtr_sha256_update(&ctx, prep_key[index] + (510 / 2), 8);
  jtr_sha256_final((unsigned char *) crypt_out[index], &ctx);
}
