for (i = 0; i < 3; i++)
{
  while ((*v) && ((*v) != ' '))
    v++;

  *v = 0;
  ((float *) d)[i] = atof(w);
  w = (v = v + 1);
}
