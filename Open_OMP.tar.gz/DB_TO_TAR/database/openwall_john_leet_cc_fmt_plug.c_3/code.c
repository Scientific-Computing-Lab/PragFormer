for (i = 0; i < 64; ++i)
  output1[i] ^= output2[i];
