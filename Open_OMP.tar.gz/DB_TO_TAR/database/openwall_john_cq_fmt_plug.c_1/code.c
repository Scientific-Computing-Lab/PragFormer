for (i = 0; username[i] != 0; i++)
{
  a += AdRandomNumbers[(i + username[i]) & 0x7ff];
}
