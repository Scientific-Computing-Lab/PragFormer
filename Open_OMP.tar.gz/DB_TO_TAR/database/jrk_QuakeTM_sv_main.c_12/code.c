for (i = 0; i < 16; i++)
  newcl->spawn_parms[i] = (&pr_global_struct->parm1)[i];
