for (index = 0; index < count; index++)
{
  adxcrypt(saved_key[index], (unsigned char *) crypt_out[index], strlen(saved_key[index]));
}

static void adxcrypt(char *input, unsigned char *output, int16_t length)
{
  char *in;
  int count;
  int32_t idx;
  uint32_t a;
  uint32_t b;
  union 
  {
    char b[8];
    uint32_t w[2];
  } buffer;
  if (length > 0)
    memcpy(buffer.b, input, length);
  else
    return;

  count = length;
  while (count < 8)
  {
    if ((count < 8) && (length > 0))
    {
      in = input;
      idx = 0;
      do
      {
        ++idx;
        buffer.b[count] = (*(in++)) + count;
        count++;
      }
      while ((count < 8) && (length > idx));
    }

  }

  idx = 0;
  a = __builtin_bswap32((buffer.w[0] + buffer.w[1]) ^ 0xCEFAEFBE);
  do
  {
    if ((a & 0xF) <= 9)
      b = a & 0xF;
    else
      b = (a & 0xF) - 7;

    ++idx;
    *(output++) = b + 48;
    a >>= 4;
  }
  while (idx < 8);
}

