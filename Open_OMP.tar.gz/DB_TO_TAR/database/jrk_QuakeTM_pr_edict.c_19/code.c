for (i = 0; i < progs->numglobaldefs; i++)
{
  pr_globaldefs[i].type = LittleShort(pr_globaldefs[i].type);
  pr_globaldefs[i].ofs = LittleShort(pr_globaldefs[i].ofs);
  pr_globaldefs[i].s_name = LittleLong(pr_globaldefs[i].s_name);
}
