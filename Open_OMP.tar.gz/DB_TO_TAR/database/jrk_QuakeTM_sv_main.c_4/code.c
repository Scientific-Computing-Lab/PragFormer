for (i = 0; i < 32; i++)
{
  cl = &svs.clients[i];
  if (((cl->state == cs_connected) || (cl->state == cs_spawned)) && (!cl->spectator))
  {
    top = atoi(Info_ValueForKey(cl->userinfo, "topcolor"));
    bottom = atoi(Info_ValueForKey(cl->userinfo, "bottomcolor"));
    top = (top < 0) ? (0) : ((top > 13) ? (13) : (top));
    bottom = (bottom < 0) ? (0) : ((bottom > 13) ? (13) : (bottom));
    ping = SV_CalcPing(cl);
    Con_Printf("%i %i %i %i \"%s\" \"%s\" %i %i\n", cl->userid, cl->old_frags, ((int) (realtime - cl->connection_started)) / 60, ping, cl->name, Info_ValueForKey(cl->userinfo, "skin"), top, bottom);
  }

}

int SV_CalcPing(client_t *cl)
{
  float ping;
  int i;
  int count;
  register client_frame_t *frame;
  ping = 0;
  count = 0;
  for (frame = cl->frames, i = 0; i < 64; i++, frame++)
  {
    if (frame->ping_time > 0)
    {
      ping += frame->ping_time;
      count++;
    }

  }

  if (!count)
    return 9999;

  ping /= count;
  return ping * 1000;
}

