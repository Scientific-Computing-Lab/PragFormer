for (i = 0, cl = svs.clients; i < 32; i++, cl++)
{
  if (level < cl->messagelevel)
    continue;

  if (!cl->state)
    continue;

  SV_PrintToClient(cl, level, string);
}

static void SV_PrintToClient(client_t *cl, int level, char *string)
{
  do
  {
    {
      ClientReliableWrite_Begin(cl, 8, Q_strlen(string) + 3);
      ClientReliableWrite_Byte(cl, level);
      ClientReliableWrite_String(cl, string);
    }
  }
  while (0);
  ;
}

