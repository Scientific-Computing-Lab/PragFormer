for (i = 0; i < 20; ++i)
{
  *(cpo++) = itoa16[(*cpi) >> 4];
  *(cpo++) = itoa16[(*cpi) & 0xF];
  ++cpi;
}
