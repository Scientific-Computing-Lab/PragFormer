for (i = 0; i < outlen; i++)
  TEMP2[i] = TEMP1[(outlen - i) - 1];
