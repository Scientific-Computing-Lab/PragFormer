for (i = 0; i < 16; ++i)
{
  if (atoi64[ARCH_INDEX(cp[i])] == 0x7F)
    return 0;

}
