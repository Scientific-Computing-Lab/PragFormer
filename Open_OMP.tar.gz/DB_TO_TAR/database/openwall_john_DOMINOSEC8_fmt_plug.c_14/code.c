for (j = 48; j > 32; j--)
{
  state[0][p0 - x[0].c] = (t0 = (*p0) ^ lotus_magic_table[j + t0]);
  state[1][p1 - x[1].c] = (t1 = (*p1) ^ lotus_magic_table[j + t1]);
  state[2][p2 - x[2].c] = (t2 = (*p2) ^ lotus_magic_table[j + t2]);
  p0++;
  p1++;
  p2++;
}
