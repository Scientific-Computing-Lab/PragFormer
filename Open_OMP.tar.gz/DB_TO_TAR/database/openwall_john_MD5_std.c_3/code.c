for (length = 0; key[length] && (length < 15); length++)
  ;
