for (i = 0; i < sv.num_edicts; i++)
{
  ent = EDICT_NUM(i);
  if (ent->free)
    continue;

  active++;
  if (ent->v.solid)
    solid++;

  if (ent->v.model)
    models++;

  if (ent->v.movetype == 4)
    step++;

}

edict_t *EDICT_NUM(int n)
{
  if ((n < 0) || (n >= 768))
    SV_Error("EDICT_NUM: bad number %i", n);

  return (edict_t *) (((byte *) sv.edicts) + (n * pr_edict_size));
}

