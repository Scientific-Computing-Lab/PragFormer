for (i = 0; i < sv.num_edicts; i++)
{
  Con_Printf("\nEDICT %i:\n", i);
  ED_PrintNum(i);
}

void ED_PrintNum(int ent)
{
  ED_Print(EDICT_NUM(ent));
}

