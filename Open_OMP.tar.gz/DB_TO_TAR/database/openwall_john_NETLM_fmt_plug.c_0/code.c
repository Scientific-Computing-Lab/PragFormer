for (i = 0; i < count; i++)
{
  setup_des_key(saved_key[i], &ks);
  DES_ecb_encrypt((DES_cblock *) challenge, (DES_cblock *) output[i], &ks, 1);
}

inline static void setup_des_key(unsigned char key_56[], DES_key_schedule *ks)
{
  DES_cblock key;
  key[0] = key_56[0];
  key[1] = (key_56[0] << 7) | (key_56[1] >> 1);
  key[2] = (key_56[1] << 6) | (key_56[2] >> 2);
  key[3] = (key_56[2] << 5) | (key_56[3] >> 3);
  key[4] = (key_56[3] << 4) | (key_56[4] >> 4);
  key[5] = (key_56[4] << 3) | (key_56[5] >> 5);
  key[6] = (key_56[5] << 2) | (key_56[6] >> 6);
  key[7] = key_56[6] << 1;
  DES_set_key_unchecked(&key, ks);
}

