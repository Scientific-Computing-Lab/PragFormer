for (index = 0; index < count; index++)
  if (!memcmp(binary, crypt_out_real[index], 8))
  return 1;

