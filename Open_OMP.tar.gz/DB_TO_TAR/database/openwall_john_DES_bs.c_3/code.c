for (index = 0; index < 16; index += 2)
{
  value = (block[index >> 3] >> ((index << 2) & 0x18)) & 0xff;
  l = DES_LM_reverse[value & 0xf];
  h = DES_LM_reverse[value >> 4];
  *(p++) = itoa16[l];
  *(p++) = itoa16[h];
}
