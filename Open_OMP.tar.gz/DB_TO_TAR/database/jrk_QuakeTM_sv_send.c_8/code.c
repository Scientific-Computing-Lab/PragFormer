for (i = 0; i < 256; i++)
{
  if (!sv.model_precache[i])
    break;

  if (!strcmp(sv.model_precache[i], "progs/spike.mdl"))
    sv_nailmodel = i;

  if (!strcmp(sv.model_precache[i], "progs/s_spike.mdl"))
    sv_supernailmodel = i;

  if (!strcmp(sv.model_precache[i], "progs/player.mdl"))
    sv_playermodel = i;

}
