for (i = 0; i < 10; ++i)
{
  if ((pPriv->FldMask & (0x00008000 << i)) == (0x00008000 << i))
  {
    char Fld[8];
    sprintf(Fld, "$$F%d", i);
    if (!strstr(&ciphertext[pPriv->dynamic_SALT_OFFSET - 1], Fld))
      return 0;

  }

}
