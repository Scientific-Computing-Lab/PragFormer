for (i = 0, cl = svs.clients; i < 32; i++, cl++)
{
  if (cl->state == cs_free)
    continue;

  if (!NET_CompareBaseAdr(net_from, cl->netchan.remote_address))
    continue;

  if (cl->netchan.qport != qport)
    continue;

  svs.stats.packets++;
  ClearRetry(ThreadId);
  if (cl->netchan.remote_address.port != net_from.port)
  {
    Con_DPrintf("SV_ReadPackets: fixing up a translated port\n");
    cl->netchan.remote_address.port = net_from.port;
  }

  if (Netchan_Process(&cl->netchan, i))
  {
    cl->send_message = true;
    if (((DEBUG & (~0x03)) & 4) && ((DEBUG & 0x03) >= 1))
      printf("Thread: %d\t\tclient %d\tname: %s\tstate %d\n", ThreadId, i, cl->name, (int) cl->state);

    if (cl->state != cs_zombie)
      SV_ExecuteClientMessage(cl);

  }

  FlushTMOutput();
}

void ClearRetry(int Id)
{
  retry[Id][0] = 0;
}

