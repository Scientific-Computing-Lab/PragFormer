for (i = 0; i < m_Dynamic_Count; ++i)
  total_len_X86[i] = Dynamic_curdat.store_keys_normal_but_precompute_hash_to_output2_base16_to_input1_offsetX;
