for (i = 0, c = svs.clients; i < 32; i++, c++)
{
  if (c->state > cs_connected)
  {
    if ((c->netchan.message.cursize + 5) <= c->netchan.message.maxsize)
    {
      MSG_WriteByte(&c->netchan.message, 54);
      MSG_WriteFloat(&c->netchan.message, srv_frametime_avg);
    }
    else
      Con_Printf("OOOPS: Didn't send the average frametime for client %d!\n", i);

  }

}

void Con_Printf(char *fmt, ...)
{
  va_list argptr;
  char msg[8192];
  __builtin_va_start(argptr);
  Q_vsprintf(msg, fmt, argptr);
  ;
  if (sv_redirected)
  {
    if ((Q_strlen(msg) + Q_strlen(outputbuf)) > ((8192 * (sizeof(char))) - 1))
      SV_FlushRedirect();

    Q_strcat(outputbuf, msg);
    return;
  }

  if (inTransaction == true)
  {
    AddMsg2List(false, msg);
    return;
  }

  Sys_Printf("%s", msg);
  if (sv_logfile)
    fprintf(sv_logfile, "%s", msg);

}

