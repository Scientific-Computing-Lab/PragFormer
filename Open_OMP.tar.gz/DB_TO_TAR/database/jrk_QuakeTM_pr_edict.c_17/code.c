for (i = 0; i < progs->numstatements; i++)
{
  pr_statements[i].op = LittleShort(pr_statements[i].op);
  pr_statements[i].a = LittleShort(pr_statements[i].a);
  pr_statements[i].b = LittleShort(pr_statements[i].b);
  pr_statements[i].c = LittleShort(pr_statements[i].c);
}
