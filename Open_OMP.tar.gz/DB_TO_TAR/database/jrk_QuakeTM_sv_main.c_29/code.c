for (q = newname; *p; *(q++) = *(p++))
  ;
