for (i = 0; i < 24; i++)
{
  binary[i] = atoi16[ARCH_INDEX(ciphertext[i * 2])] << 4;
  binary[i] |= atoi16[ARCH_INDEX(ciphertext[(i * 2) + 1])];
}
