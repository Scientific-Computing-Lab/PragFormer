for (i = 0; i < 4; i++)
{
  if (((*s) < '0') || ((*s) > '9'))
  {
    Con_Printf("Bad filter address: %s\n", s);
    return false;
  }

  j = 0;
  while (((*s) >= '0') && ((*s) <= '9'))
  {
    num[j++] = *(s++);
  }

  num[j] = 0;
  b[i] = atoi(num);
  if (b[i] != 0)
    m[i] = 255;

  if (!(*s))
    break;

  s++;
}
