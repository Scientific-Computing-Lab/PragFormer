for (i = 0; i < 10; i++)
  newcl->whensaid[i] = 0.0;
