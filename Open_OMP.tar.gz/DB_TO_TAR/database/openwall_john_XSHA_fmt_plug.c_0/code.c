for (i = 0; i < count; i++)
{
  sph_sha1_context ctx;
  memcpy(&ctx, &ctx_salt, sizeof(ctx));
  sph_sha1(&ctx, saved_key[i], saved_len[i]);
  sph_sha1_close(&ctx, (unsigned char *) crypt_out[i]);
}
