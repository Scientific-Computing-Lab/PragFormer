for (t = 0; t < (n * (((sizeof(DES_bs_combined)) + (64 - 1)) & (~(64 - 1)))); t += ((sizeof(DES_bs_combined)) + (64 - 1)) & (~(64 - 1)))
{
  value = binary[0];
  b = (long *) (&(*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).B[0]);
  mask = b[0] ^ (-(value & 1));
  mask |= b[1] ^ (-((value >> 1) & 1));
  mask |= b[2] ^ (-((value >> 2) & 1));
  mask |= b[3] ^ (-((value >> 3) & 1));
  if (mask == (~((long) 0)))
    goto next_depth;

  value >>= 4;
  b += 4;
  for (bit = 4; bit < 32; bit += 2)
  {
    mask |= b[0] ^ (-(value & 1));
    if (mask == (~((long) 0)))
      goto next_depth;

    mask |= b[1] ^ (-((value >> 1) & 1));
    if (mask == (~((long) 0)))
      goto next_depth;

    value >>= 2;
    b += 2;
  }

  retval = 1;
  next_depth:
  ;

}
