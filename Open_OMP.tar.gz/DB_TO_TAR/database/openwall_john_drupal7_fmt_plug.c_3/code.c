for (index = 0; index < count; index++)
  if (!memcmp(binary, crypt_key[index], ARCH_SIZE))
  return 1;

