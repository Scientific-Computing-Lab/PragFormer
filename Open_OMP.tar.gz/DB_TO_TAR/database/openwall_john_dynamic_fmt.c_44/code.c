for (; j < til; ++j)
{
  memcpy(&input_buf2_X86[j >> MD5_X2].x1.b[total_len2_X86[j]], Str, len);
  total_len2_X86[j] += len;
}
