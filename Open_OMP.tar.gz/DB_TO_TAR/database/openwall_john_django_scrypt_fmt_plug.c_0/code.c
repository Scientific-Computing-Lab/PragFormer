for (index = 0; index < count; index++)
{
  int t = omp_get_thread_num();
  if (t >= max_threads)
  {
    failed = -1;
    continue;
  }

  if (yescrypt_kdf(0, &local[t], (const uint8_t *) saved_key[index], strlen(saved_key[index]), (const uint8_t *) cur_salt->salt, strlen(cur_salt->salt), &params, (uint8_t *) crypt_out[index], sizeof(crypt_out[index])))
  {
    failed = (errno) ? (errno) : (EINVAL);
  }

}
