for (i = 0; i < l; i++)
{
  if ((string[i] == '\\') && (i < (l - 1)))
  {
    i++;
    if (string[i] == 'n')
      *(new_p++) = '\n';
    else
      *(new_p++) = '\\';

  }
  else
    *(new_p++) = string[i];

}
