for (; i < (((1 << MD5_X2) * 2) * 2); ++i)
{
  memset(input_buf_X86[i >> MD5_X2].x1.b, 0, (total_len_X86[i] > ((sizeof(input_buf_X86[0].x1.b)) - 8)) ? (sizeof(input_buf_X86[0].x1.b)) : (total_len_X86[i] + 8));
  total_len_X86[i] = 0;
}
