for (i = 0; i < 20; i++)
{
  realcipher[i] = (atoi16[ARCH_INDEX(ciphertext[i * 2])] * 16) + atoi16[ARCH_INDEX(ciphertext[(i * 2) + 1])];
}
