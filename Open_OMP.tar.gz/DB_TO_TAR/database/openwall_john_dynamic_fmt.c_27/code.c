for (i = 0; i < 10; ++i, bit <<= 1)
{
  if (nFlds[i])
  {
    *(Buffer++) = nFlds[i];
    memcpy((char *) Buffer, (char *) Flds[i], nFlds[i]);
    Buffer += nFlds[i];
    bit_array &= ~bit;
    if (!bit_array)
      return the_real_len;

  }

}
