for (i = 0, cl = svs.clients; i < 32; i++, cl++)
{
  if ((cl->state == cs_connected) || (cl->state == cs_spawned))
  {
    if (!cl->spectator)
      nclients++;

    if (cl->netchan.last_received < droptime)
    {
      SV_BroadcastPrintf(2, "%s timed out\n", cl->name);
      SV_DropClient(cl);
      cl->state = cs_free;
    }

  }

  if ((cl->state == cs_zombie) && ((realtime - cl->connection_started) > zombietime.value))
  {
    cl->state = cs_free;
  }

}

void SV_DropClient(client_t *drop)
{
  do
  {
    {
      MSG_WriteByte(&drop->netchan.message, 2);
    }
  }
  while (0);
  ;
  if (drop->state == cs_spawned)
  {
    if (!drop->spectator)
    {
      pr_global_struct->self = ((byte *) drop->edict) - ((byte *) sv.edicts);
      PR_ExecuteProgram(pr_global_struct->ClientDisconnect);
    }
    else
      if (SpectatorDisconnect)
    {
      pr_global_struct->self = ((byte *) drop->edict) - ((byte *) sv.edicts);
      PR_ExecuteProgram(SpectatorDisconnect);
    }


  }

  if (drop->spectator)
    Con_Printf("Spectator %s removed\n", drop->name);
  else
    Con_Printf("Client %s removed\n", drop->name);

  if (drop->download)
  {
    TM_fclose(drop->download);
    drop->download = 0;
  }

  if (drop->upload)
  {
    TM_fclose(drop->upload);
    drop->upload = 0;
  }

  *drop->uploadfn = 0;
  drop->state = cs_zombie;
  drop->connection_started = realtime;
  drop->old_frags = 0;
  drop->edict->v.frags = 0;
  drop->name[0] = 0;
  Q_memset(drop->userinfo, 0, sizeof(drop->userinfo));
  do
  {
    {
      do
      {
        {
          SV_FullClientUpdate(drop, &sv.reliable_datagram);
        }
      }
      while (0);
      ;
    }
  }
  while (0);
  ;
}

