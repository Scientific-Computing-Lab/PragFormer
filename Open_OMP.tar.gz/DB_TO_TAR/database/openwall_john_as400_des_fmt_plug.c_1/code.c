for (i = 0; i < n; ++i)
  str[i] = a2e[str[i]];
