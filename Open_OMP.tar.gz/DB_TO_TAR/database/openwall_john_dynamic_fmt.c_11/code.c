for (i = 0; i < m_ompt; ++i)
{
  dyna_eLargeOut[i] = eBase16;
  dyna_nLargeOff[i] = 0;
}
