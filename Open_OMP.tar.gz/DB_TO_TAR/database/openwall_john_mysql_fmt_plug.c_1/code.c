for (i = 0; i < 16; i++)
  if (atoi16[ARCH_INDEX(ciphertext[i])] > 15)
  return 0;

