for (i = 0; i < cipherTextLen; i++)
{
  if (atoi16[ARCH_INDEX(cp[i])] == 0x7f)
    return 0;

}
