for (i = 0; i < count; i++)
  if ((*((uint32_t *) binary)) == crypt_key[i][0])
{
  #pragma omp atomic
  retval |= 1;
}

