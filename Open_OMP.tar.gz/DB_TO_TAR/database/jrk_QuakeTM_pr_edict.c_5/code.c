for (i = 0; i < progs->numfunctions; i++)
{
  func = &pr_functions[i];
  if (!strcmp(PR_GetString(func->s_name), name))
    return func;

}
