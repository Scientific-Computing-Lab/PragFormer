for (i = 0; i < cs.data_size; i++)
  cs.chunk[i] = (atoi16[ARCH_INDEX(p[i * 2])] * 16) + atoi16[ARCH_INDEX(p[(i * 2) + 1])];
