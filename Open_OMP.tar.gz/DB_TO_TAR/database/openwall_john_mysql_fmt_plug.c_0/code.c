for (i = 0; i < count; i++)
{
  unsigned char *p = (unsigned char *) saved_key[i];
  if (*p)
  {
    uint32_t nr;
    uint32_t add;
    uint32_t tmp;
    while (((*p) == ' ') || ((*p) == '\t'))
      p++;

    tmp = (uint32_t) ((unsigned char) (*(p++)));
    nr = 1345345333 ^ ((((1345345333 & 63) + 7) * tmp) + (1345345333U << 8));
    add = 7 + tmp;
    for (; *p; p++)
    {
      if (((*p) == ' ') || ((*p) == '\t'))
        continue;

      tmp = (uint32_t) ((unsigned char) (*p));
      nr ^= (((nr & 63) + add) * tmp) + (nr << 8);
      add += tmp;
    }

    crypt_key[i][0] = nr & ((((uint32_t) 1) << 31) - 1);
    continue;
  }

  crypt_key[i][0] = 1345345333 & ((((uint32_t) 1) << 31) - 1);
}
