for (t = 0; t < omp_para; t++)
  md5cryptsse((unsigned char *) (&saved_key[t * (1 * 4)]), cursalt, (char *) (&sout[((t * (1 * 4)) * 16) / (sizeof(MD5_word))]), CryptType);
