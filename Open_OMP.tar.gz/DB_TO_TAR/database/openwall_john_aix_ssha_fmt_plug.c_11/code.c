for (index = 0; index < count; index++)
{
  if (!memcmp(binary, crypt_out[index], (20 - 2) - 2))
    return 1;

}
