for (ic = 0; ic < cur_salt->iterations; ic++)
{
  jtr_sha256_init(&ctx, 1);
  pkd.iteration_count = __builtin_bswap64(ic);
  jtr_sha256_update(&ctx, &pkd, sizeof(struct libbde_password_key_data));
  jtr_sha256_final(pkd.last_sha256_hash, &ctx);
}
