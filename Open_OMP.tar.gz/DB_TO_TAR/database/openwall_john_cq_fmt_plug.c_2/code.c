for (i = 0; password[i] != 0; i++)
{
  a += AdRandomNumbers[((i + password[i]) + userlength) & 0x7ff];
}
