for (i = 0; i < sv.num_edicts; i++)
{
  edict_t *ent = (edict_t *) (ent_global_ptr + (pr_edict_size * i));
  if (ent->free || (i <= 32))
    continue;

  if (((DEBUG & (~0x03)) & 8) && ((DEBUG & 0x03) >= 2))
    printf("Thread= %d\t\tBefore Transaction\n", omp_get_thread_num());

  inTransaction = true;
  SV_RunEntity(ent);
  SV_RunNewmis();
  inTransaction = false;
  if (((DEBUG & (~0x03)) & 8) && ((DEBUG & 0x03) >= 2))
    printf("Thread= %d\t\tAfter Transaction\n", omp_get_thread_num());

  FlushTMOutput();
}

void SV_RunEntity(edict_t *ent)
{
  if (ent->v.lastruntime == ((float) realtime))
    return;

  ent->v.lastruntime = (float) realtime;
  switch ((int) ent->v.movetype)
  {
    case 7:
      SV_Physics_Pusher(ent);
      break;

    case 0:
      SV_Physics_None(ent);
      break;

    case 8:
      SV_Physics_Noclip(ent);
      break;

    case 4:
      SV_Physics_Step(ent);
      break;

    case 3:

    case 6:

    case 10:

    case 5:

    case 9:
      SV_Physics_Toss(ent);
      break;

    default:
      SV_Error("SV_Physics: bad movetype %i", (int) ent->v.movetype);

  }

}


void SV_RunNewmis(void)
{
  edict_t *ent;
  if (!pr_global_struct->newmis)
    return;

  ent = (edict_t *) (((byte *) sv.edicts) + pr_global_struct->newmis);
  host_frametime = 0.05;
  pr_global_struct->newmis = 0;
  SV_RunEntity(ent);
}

