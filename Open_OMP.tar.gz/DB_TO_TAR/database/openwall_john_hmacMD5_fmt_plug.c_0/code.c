for (index = 0; index < count; index += 1)
{
  MD5_CTX ctx;
  if (new_keys)
  {
    john_MD5_Init(&ipad_ctx[index]);
    john_MD5_Update(&ipad_ctx[index], ipad[index], 64);
    john_MD5_Init(&opad_ctx[index]);
    john_MD5_Update(&opad_ctx[index], opad[index], 64);
  }

  memcpy(&ctx, &ipad_ctx[index], sizeof(ctx));
  john_MD5_Update(&ctx, cur_salt, strlen((char *) cur_salt));
  john_MD5_Final((unsigned char *) crypt_key[index], &ctx);
  memcpy(&ctx, &opad_ctx[index], sizeof(ctx));
  john_MD5_Update(&ctx, crypt_key[index], 16);
  john_MD5_Final((unsigned char *) crypt_key[index], &ctx);
}
