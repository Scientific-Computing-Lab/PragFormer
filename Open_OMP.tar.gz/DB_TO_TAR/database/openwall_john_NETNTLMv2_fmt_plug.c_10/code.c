for (i = 0; i < (16 / 2); i++)
  binary_salt[(((identity_length + 1) + 2) + 1) + i] = (atoi16[ARCH_INDEX(ciphertext[i * 2])] << 4) + atoi16[ARCH_INDEX(ciphertext[(i * 2) + 1])];
