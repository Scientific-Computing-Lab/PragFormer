for (i = 0; i < 8; ++i)
{
  out.c[i] = (atoi16[ARCH_INDEX(ciphertext[i * 2])] << 4) + atoi16[ARCH_INDEX(ciphertext[(i * 2) + 1])];
}
