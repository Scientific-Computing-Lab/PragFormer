for (i = 0; i < 4; i++)
{
  b[i] = ((atoi64[ARCH_INDEX(pos[(i * 4) + 0])] + (atoi64[ARCH_INDEX(pos[(i * 4) + 1])] << 6)) + (atoi64[ARCH_INDEX(pos[(i * 4) + 2])] << 12)) + (atoi64[ARCH_INDEX(pos[(i * 4) + 3])] << 18);
}
