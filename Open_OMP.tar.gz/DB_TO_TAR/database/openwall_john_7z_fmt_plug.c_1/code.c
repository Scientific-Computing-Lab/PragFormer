for (round = 0; round < rounds; round++)
{
  if (sevenzip_salt->SaltSize)
    jtr_sha256_update(&sha, sevenzip_salt->salt, sevenzip_salt->SaltSize);

  jtr_sha256_update(&sha, (char *) saved_key[index], saved_len[index]);
  jtr_sha256_update(&sha, temp, 8);
  for (i = 0; i < 8; i++)
    if ((++temp[i]) != 0)
    break;


}
