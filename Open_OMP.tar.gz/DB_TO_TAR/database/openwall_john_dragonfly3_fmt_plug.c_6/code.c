for (i = 0; i < (*((unsigned char *) salt)); i++)
  hash = ((hash << 5) + hash) ^ s[i];
