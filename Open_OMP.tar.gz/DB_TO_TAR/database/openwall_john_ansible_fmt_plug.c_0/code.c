for (index = 0; index < count; index += 1)
{
  unsigned char master[1][32];
  int i;
  for (i = 0; i < 1; ++i)
    pbkdf2_sha256((unsigned char *) saved_key[index + i], strlen(saved_key[index + i]), cur_salt->salt, cur_salt->salt_length, cur_salt->iterations, master[i], 32, 32);

  for (i = 0; i < 1; ++i)
  {
    JTR_hmac_sha256(master[i], 32, cur_salt->blob, cur_salt->bloblen, (unsigned char *) crypt_out[index + i], 16);
  }

}

static void pbkdf2_sha256(const unsigned char *K, int KL, unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[32 / (sizeof(uint32_t))];
    unsigned char out[32];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  jtr_sha256_ctx ipad;
  jtr_sha256_ctx opad;
  _pbkdf2_sha256_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (32 - 1)) / 32;
  loop = (skip_bytes / 32) + 1;
  skip_bytes %= 32;
  while (loop <= loops)
  {
    _pbkdf2_sha256(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 32) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}

