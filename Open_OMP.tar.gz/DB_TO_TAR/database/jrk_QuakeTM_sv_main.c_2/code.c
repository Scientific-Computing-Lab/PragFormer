for (i = 0, cl = svs.clients; i < 32; i++, cl++)
  if (cl->state >= cs_spawned)
  Netchan_Transmit(&cl->netchan, net_message.cursize, net_message.data);

