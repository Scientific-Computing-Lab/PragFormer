for (i = 0; i < 3; i++)
  MSG_WriteAngle(msg, ent->v.angles[i]);
