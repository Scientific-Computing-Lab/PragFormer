for (i = 0; i < NoThreads; i++)
{
  printf("Thread %d execute init for globals for i = %d\n", omp_get_thread_num(), i);
  if (omp_get_thread_num() > 0)
  {
    pr_globals = (float *) malloc(progs->numglobals * (sizeof(float)));
    pr_global_struct = (globalvars_t *) pr_globals;
    memcpy(pr_globals, pr_globals_temp, progs->numglobals * (sizeof(float)));
  }
  else
  {
    pr_global_struct = pr_global_struct_temp;
    pr_globals = (float *) pr_global_struct;
  }

}
