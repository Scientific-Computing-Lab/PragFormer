for (i = 0; i < numipfilters; i++)
{
  *((unsigned *) b) = ipfilters[i].compare;
  fprintf(f, "addip %i.%i.%i.%i\n", b[0], b[1], b[2], b[3]);
}
