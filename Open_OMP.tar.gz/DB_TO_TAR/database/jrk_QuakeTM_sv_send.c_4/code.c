for (j = 0, client = svs.clients; j < 32; j++, client++)
{
  if (client->state != cs_spawned)
    continue;

  inrange = false;
  if ((to == 4) || (to == 1))
  {
    vec3_t delta;
    {
      delta[0] = origin[0] - client->edict->v.origin[0];
      delta[1] = origin[1] - client->edict->v.origin[1];
      delta[2] = origin[2] - client->edict->v.origin[2];
    }
    ;
    if (Length(delta) <= 1024)
      inrange = true;

  }

  if (!inrange)
  {
    leaf = Mod_PointInLeaf(client->edict->v.origin, sv.worldmodel);
    if (leaf)
    {
      leafnum = (leaf - sv.worldmodel->leafs) - 1;
      if (!(mask[leafnum >> 3] & (1 << (leafnum & 7))))
      {
        continue;
      }

    }

  }

  do
  {
    {
      if (reliable)
      {
        ClientReliableCheckBlock(client, sv.multicast.cursize);
        ClientReliableWrite_SZ(client, sv.multicast.data, sv.multicast.cursize);
      }
      else
        SZ_Write(&client->datagram, sv.multicast.data, sv.multicast.cursize);

    }
  }
  while (0);
  ;
}
