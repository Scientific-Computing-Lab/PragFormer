for (index = 0; index < count; index += 1)
{
  sph_whirlpool_context wctx;
  int i;
  union 
  {
    unsigned char buf[64];
    uint64_t p64[1];
  } output1[1];
  union 
  {
    unsigned char buf[64];
    uint64_t p64[1];
  } output2;
  jtr_sha512_ctx sctx;
  jtr_sha512_init(&sctx, 1);
  jtr_sha512_update(&sctx, saved_key[index], saved_len[index]);
  jtr_sha512_update(&sctx, cur_salt->salt, cur_salt->saltlen);
  jtr_sha512_final(output1[0].buf, &sctx);
  for (i = 0; i < 1; ++i)
  {
    sph_whirlpool_init(&wctx);
    sph_whirlpool(&wctx, cur_salt->salt, cur_salt->saltlen);
    sph_whirlpool(&wctx, saved_key[index + i], saved_len[index + i]);
    sph_whirlpool_close(&wctx, output2.buf);
    crypt_out[index + i][0] = output1[i].p64[0] ^ output2.p64[0];
  }

}
