for (i = 0; i < sc_threads; i++)
{
  if (pseudo_rands[i])
  {
    free(pseudo_rands[i]);
    pseudo_rands[i] = 0;
  }

}
