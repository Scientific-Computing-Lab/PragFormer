for (i = 0, cl = svs.clients; i < 32; i++, cl++)
{
  if (cl->state == cs_free)
    continue;

  if (cl->spectator)
    spectators++;
  else
    clients++;

}
