for (; *p; p++)
{
  if (((*p) == ' ') || ((*p) == '\t'))
    continue;

  tmp = (uint32_t) (*p);
  nr ^= (((nr & 63) + add) * tmp) + (nr << 8);
  nr2 += (nr2 << 8) ^ nr;
  add += tmp;
}
