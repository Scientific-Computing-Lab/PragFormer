for (i = 0; i < 10; ++i)
{
  if (pPriv->FldMask & (0x00008000 << i))
  {
    sprintf(Tmp, "$$F%d", i);
    if (((split_fields[i] && split_fields[i][0]) && strcmp(split_fields[i], "/")) && (!strstr(cpBuilding, Tmp)))
    {
      static char ct[1024];
      char ct2[1024];
      snprintf(ct2, sizeof(ct2), "%s$$F%d%s", cpBuilding, i, split_fields[i]);
      strcpy(ct, ct2);
      cpBuilding = ct;
    }

  }

}
