for (i = 0; i < 10; ++i, bit <<= 1)
{
  if (todo_bits & bit)
  {
    todo_bits ^= bit;
    fld_lens[i] = *(cpsalt++);
    flds[i] = cpsalt;
    if (todo_bits == 0)
      return;

    cpsalt += fld_lens[i];
  }

}
