for (index = 0; index < count; index++)
  *crypt_key[index] = AdEncryptPassword(saved_salt, saved_key[index]);

unsigned int AdEncryptPassword(const char *username, const char *password)
{
  unsigned int userlength;
  unsigned int passlength;
  unsigned int a = 0;
  int i;
  for (i = 0; username[i] != 0; i++)
  {
    a += AdRandomNumbers[(i + username[i]) & 0x7ff];
  }

  userlength = i;
  for (i = 0; password[i] != 0; i++)
  {
    a += AdRandomNumbers[((i + password[i]) + userlength) & 0x7ff];
  }

  passlength = i;
  return AdRandomNumbers[(userlength + passlength) & 0x7ff] + a;
}

