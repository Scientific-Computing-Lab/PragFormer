for (i = 0; i < 7; ++i)
{
  fmt_Dynamic.methods.binary_hash[i] = pFmt->methods.binary_hash[i];
  fmt_Dynamic.methods.get_hash[i] = pFmt->methods.get_hash[i];
}
