for (ii = 0; ii < 3; ii++)
{
  sz[ii] = nvol->axis[map[ii]].size;
  sp[ii] = sqrt(((nvol->axis[map[ii]].spaceDirection[0] * nvol->axis[map[ii]].spaceDirection[0]) + (nvol->axis[map[ii]].spaceDirection[1] * nvol->axis[map[ii]].spaceDirection[1])) + (nvol->axis[map[ii]].spaceDirection[2] * nvol->axis[map[ii]].spaceDirection[2]));
}
