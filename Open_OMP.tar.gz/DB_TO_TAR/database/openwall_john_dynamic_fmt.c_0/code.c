for (i = 0; i < m_Dynamic_Count; i += inc)
  DynamicFunc__crypt2_md5(i, i + inc, omp_get_thread_num());

void DynamicFunc__crypt2_md5(unsigned int first, unsigned int last, unsigned int tid)
{
  unsigned int i;
  unsigned int til;
  i = first;
  til = last;
  for (; i < til; ++i)
  {
    unsigned int len = total_len2_X86[i];
    do
    {
      if ((!force_md5_ctx) && (len < 55))
      {
        input_buf2_X86[i >> MD5_X2].x1.b[len] = 0x80;
        input_buf2_X86[i >> MD5_X2].x1.w[14] = len << 3;
        MD5_swap(input_buf2_X86[i >> MD5_X2].x1.w, input_buf2_X86[i >> MD5_X2].x1.w, (len + 4) >> 2);
        MD5_body_for_thread(0, input_buf2_X86[i >> MD5_X2].x1.w, crypt_key2_X86[i >> MD5_X2].x1.w);
        MD5_swap(crypt_key2_X86[i >> MD5_X2].x1.w, crypt_key2_X86[i >> MD5_X2].x1.w, 4);
      }
      else
      {
        MD5_CTX ctx;
        john_MD5_Init(&ctx);
        john_MD5_Update(&ctx, input_buf2_X86[i >> MD5_X2].x1.b, len);
        john_MD5_Final((unsigned char *) crypt_key2_X86[i >> MD5_X2].x1.b, &ctx);
      }

    }
    while (0);
  }

}

