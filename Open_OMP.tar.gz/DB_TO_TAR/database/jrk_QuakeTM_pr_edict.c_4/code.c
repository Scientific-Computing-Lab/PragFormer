for (i = 0; i < progs->numfielddefs; i++)
{
  def = &pr_fielddefs[i];
  if (!Q_strcmp(PR_GetString(def->s_name), name))
    return def;

}
