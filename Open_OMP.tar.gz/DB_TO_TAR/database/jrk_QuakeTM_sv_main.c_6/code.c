for (i = 0; i < 1024; i++)
{
  if (NET_CompareBaseAdr(net_from, svs.challenges[i].adr))
  {
    if (challenge == svs.challenges[i].challenge)
      break;

    Netchan_OutOfBandPrint(net_from, "%c\nBad challenge.\n", 'n');
    return;
  }

}
