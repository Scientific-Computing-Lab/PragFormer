for (i = 0; i < 16; i++)
  cs.iv[i] = (atoi16[ARCH_INDEX(p[i * 2])] * 16) + atoi16[ARCH_INDEX(p[(i * 2) + 1])];
