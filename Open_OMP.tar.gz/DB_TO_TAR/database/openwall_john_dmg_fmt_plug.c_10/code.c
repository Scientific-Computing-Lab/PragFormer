for (i = 0; i < cs.len_wrapped_aes_key; i++)
  cs.wrapped_aes_key[i] = (atoi16[ARCH_INDEX(p[i * 2])] * 16) + atoi16[ARCH_INDEX(p[(i * 2) + 1])];
