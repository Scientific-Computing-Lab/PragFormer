for (; j > 16; j--)
{
  t0 = block0[(p0 - x[0].c) - 16] ^ lotus_magic_table[j + t0];
  t1 = block1[(p1 - x[1].c) - 16] ^ lotus_magic_table[j + t1];
  t2 = block2[(p2 - x[2].c) - 16] ^ lotus_magic_table[j + t2];
  *(p0++) = t0;
  *(p1++) = t1;
  *(p2++) = t2;
}
