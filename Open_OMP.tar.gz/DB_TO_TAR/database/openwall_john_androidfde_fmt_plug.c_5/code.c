for (i = 0; i < cs.keysize; i++)
{
  cs.mkey[i] = (atoi16[ARCH_INDEX(*p)] << 4) | atoi16[ARCH_INDEX(p[1])];
  p += 2;
}
