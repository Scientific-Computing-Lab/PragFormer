for (i = 0, j = 0; i < 16; i += 2, j++)
{
  out[j] = (in[i] + in[i + 1]) % 62;
  if (out[j] < 10)
  {
    out[j] += 48;
  }
  else
    if (out[j] < 36)
  {
    out[j] += 55;
  }
  else
  {
    out[j] += 61;
  }


}
