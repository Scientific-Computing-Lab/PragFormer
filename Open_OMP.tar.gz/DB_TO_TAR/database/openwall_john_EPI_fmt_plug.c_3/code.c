for (n = 0; n < len; ++n)
  dst[n] = (atoi16[ARCH_INDEX(src[n * 2])] << 4) | atoi16[ARCH_INDEX(src[(n * 2) + 1])];
