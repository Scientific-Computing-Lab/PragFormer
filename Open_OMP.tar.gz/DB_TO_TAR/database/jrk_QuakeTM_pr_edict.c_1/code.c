for (i = 32 + 1; i < sv.num_edicts; i++)
{
  e = EDICT_NUM(i);
  if (e->free && ((e->freetime < 2) || ((sv.time - e->freetime) > 0.5)))
  {
    ED_ClearEdict(e);
    relaxed = true;
  }

}

edict_t *EDICT_NUM(int n)
{
  if ((n < 0) || (n >= 768))
    SV_Error("EDICT_NUM: bad number %i", n);

  return (edict_t *) (((byte *) sv.edicts) + (n * pr_edict_size));
}


void ED_ClearEdict(edict_t *e)
{
  Q_memset(&e->v, 0, progs->entityfields * 4);
  e->free = false;
}

