for (i = 0; i < count; ++i)
{
  sph_sha1_context ctx;
  sph_sha1_init(&ctx);
  sph_sha1(&ctx, (unsigned char *) global_salt, 30 - 1);
  sph_sha1(&ctx, saved_key[i], key_len[i]);
  sph_sha1_close(&ctx, (unsigned char *) crypt_out[i]);
}
