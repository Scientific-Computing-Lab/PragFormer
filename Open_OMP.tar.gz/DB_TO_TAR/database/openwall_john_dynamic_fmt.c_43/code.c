for (; j < til; ++j)
{
  unsigned int z;
  unsigned char *cp;
  unsigned char *cpi = Str;
  if ((total_len2_X86[j] + (len << 1)) <= (256 - 17))
  {
    cp = &input_buf2_X86[j >> MD5_X2].x1.B[total_len2_X86[j]];
    for (z = 0; z < len; ++z)
    {
      *(cp++) = *(cpi++);
      *(cp++) = 0;
    }

    total_len2_X86[j] += len << 1;
  }

}
