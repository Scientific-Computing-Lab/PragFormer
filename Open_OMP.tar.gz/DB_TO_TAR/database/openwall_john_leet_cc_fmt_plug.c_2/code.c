for (index = 0; index < count; index++)
  if (((uint64_t *) binary)[0] == crypt_out[index][0])
  return 1;

