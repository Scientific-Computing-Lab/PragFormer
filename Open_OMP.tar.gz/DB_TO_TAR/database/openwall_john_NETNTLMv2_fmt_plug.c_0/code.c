for (i = 0; i < count; i++)
{
  unsigned char ntlm_v2_hash[16];
  HMACMD5Context ctx;
  if (!keys_prepared)
  {
    unsigned char ntlm[16];
    int len;
    len = E_md4hash(saved_plain[i], saved_len[i], ntlm);
    hmac_md5_init_K16(ntlm, &saved_ctx[i]);
    if (len <= 0)
      saved_plain[i][-len] = 0;

  }

  memcpy(&ctx, &saved_ctx[i], sizeof(ctx));
  hmac_md5_update((unsigned char *) (&challenge[1]), identity_length, &ctx);
  hmac_md5_final(ntlm_v2_hash, &ctx);
  hmac_md5(ntlm_v2_hash, (((challenge + 1) + identity_length) + 1) + 2, challenge_size, (unsigned char *) output[i]);
}
