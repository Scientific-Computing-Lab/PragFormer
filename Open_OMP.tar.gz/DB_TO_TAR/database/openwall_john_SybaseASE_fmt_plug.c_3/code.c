for (index = 0; index < kpc; index++)
{
  memcpy(((unsigned char *) prep_key[index]) + 510, (unsigned char *) salt, 8);
}
