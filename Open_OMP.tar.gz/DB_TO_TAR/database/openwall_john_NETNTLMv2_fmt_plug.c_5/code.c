for (pos = ciphertext + ((sizeof("$NETNTLMv2$")) - 1); (*pos) != '$'; pos++)
  ;
