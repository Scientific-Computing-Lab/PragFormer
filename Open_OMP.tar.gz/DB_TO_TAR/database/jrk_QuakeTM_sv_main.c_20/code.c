for (i = 0; i < numipfilters; i++)
  if ((in & ipfilters[i].mask) == ipfilters[i].compare)
  return (filterban.value == 0) ? (false) : (true);

