for (i = 0; i < cs.encrypted_keyblob_size; i++)
  cs.encrypted_keyblob[i] = (atoi16[ARCH_INDEX(p[i * 2])] * 16) + atoi16[ARCH_INDEX(p[(i * 2) + 1])];
