for (i = 4; x; --x, i += 2)
{
  *(cp++) = (atoi16[ARCH_INDEX(p[i])] * 16) + atoi16[ARCH_INDEX(p[i + 1])];
}
