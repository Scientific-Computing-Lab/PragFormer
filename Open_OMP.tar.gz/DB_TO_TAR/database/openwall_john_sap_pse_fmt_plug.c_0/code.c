for (index = 0; index < count; index += 1)
{
  unsigned char key[1][24];
  unsigned char iv[1][8];
  int i;
  for (i = 0; i < 1; i++)
  {
    pkcs12_pbe_derive_key(1, cur_salt->iterations, 1, (unsigned char *) saved_key[index + i], saved_len[index + i], cur_salt->salt, cur_salt->salt_size, key[i], 24);
    pkcs12_pbe_derive_key(1, cur_salt->iterations, 2, (unsigned char *) saved_key[index + i], saved_len[index + i], cur_salt->salt, cur_salt->salt_size, iv[i], 8);
  }

  for (i = 0; i < 1; i++)
  {
    unsigned char out[16];
    unsigned char input[48 + 8];
    int padbyte;
    DES_cblock ivec;
    DES_key_schedule ks1;
    DES_key_schedule ks2;
    DES_key_schedule ks3;
    DES_set_key_unchecked((DES_cblock *) key[i], &ks1);
    DES_set_key_unchecked((DES_cblock *) (key[i] + 8), &ks2);
    DES_set_key_unchecked((DES_cblock *) (key[i] + 16), &ks3);
    memcpy(ivec, iv[i], 8);
    memcpy(input, saved_key[index + i], saved_len[index + i]);
    padbyte = 8 - (saved_len[index + i] % 8);
    if ((padbyte < 8) && (padbyte > 0))
      memset(input + saved_len[index + i], padbyte, padbyte);

    DES_ede3_cbc_encrypt(input, out, 8, &ks1, &ks2, &ks3, &ivec, 1);
    cracked[index + i] = !memcmp(out, cur_salt->encrypted_pin, 8);
  }

}
