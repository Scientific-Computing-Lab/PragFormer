for (i = 0; i < 32; i++)
{
  host_client = &svs.clients[i];
  if (host_client->state != cs_spawned)
    continue;

  inTransaction = true;
  do
  {
    {
      if (host_client->sendinfo)
      {
        host_client->sendinfo = false;
        SV_FullClientUpdate(host_client, &sv.reliable_datagram);
      }

      if (host_client->old_frags != host_client->edict->v.frags)
      {
        for (j = 0, client = svs.clients; j < 32; j++, client++)
        {
          if (client->state < cs_connected)
            continue;

          ClientReliableWrite_Begin(client, 14, 4);
          ClientReliableWrite_Byte(client, i);
          ClientReliableWrite_Short(client, host_client->edict->v.frags);
        }

        host_client->old_frags = host_client->edict->v.frags;
      }

      ent = host_client->edict;
      val = GetEdictFieldValue(ent, "gravity");
      if (val && (host_client->entgravity != val->_float))
      {
        host_client->entgravity = val->_float;
        ClientReliableWrite_Begin(host_client, 50, 5);
        ClientReliableWrite_Float(host_client, host_client->entgravity);
      }

      val = GetEdictFieldValue(ent, "maxspeed");
      if (val && (host_client->maxspeed != val->_float))
      {
        host_client->maxspeed = val->_float;
        ClientReliableWrite_Begin(host_client, 49, 5);
        ClientReliableWrite_Float(host_client, host_client->maxspeed);
      }

    }
  }
  while (0);
  ;
  inTransaction = false;
  FlushTMOutput();
}
