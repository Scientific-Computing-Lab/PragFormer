for (bit = 26; bit >= 0; bit--)
  if (((((unsigned int) (*((unsigned char *) (&b[bit])))) >> index) ^ (binary[0] >> bit)) & 1)
  return 0;

