for (i = 0; i < 16; i++)
{
  out[i] = (atoi16[ARCH_INDEX(*p)] << 4) | atoi16[ARCH_INDEX(p[1])];
  p += 2;
}
