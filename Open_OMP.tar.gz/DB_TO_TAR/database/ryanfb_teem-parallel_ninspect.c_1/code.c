for (ii = 0; ii < 3; ii++)
{
  dot[0] = ((vec[ii][0] * nvol->axis[0].spaceDirection[0]) + (vec[ii][1] * nvol->axis[0].spaceDirection[1])) + (vec[ii][2] * nvol->axis[0].spaceDirection[2]);
  dot[1] = ((vec[ii][0] * nvol->axis[1].spaceDirection[0]) + (vec[ii][1] * nvol->axis[1].spaceDirection[1])) + (vec[ii][2] * nvol->axis[1].spaceDirection[2]);
  dot[2] = ((vec[ii][0] * nvol->axis[2].spaceDirection[0]) + (vec[ii][1] * nvol->axis[2].spaceDirection[1])) + (vec[ii][2] * nvol->axis[2].spaceDirection[2]);
  dot[0] = (dot[0] > 0.0f) ? (dot[0]) : (-dot[0]);
  dot[1] = (dot[1] > 0.0f) ? (dot[1]) : (-dot[1]);
  dot[2] = (dot[2] > 0.0f) ? (dot[2]) : (-dot[2]);
  map[ii] = (dot[0] > dot[1]) ? ((dot[1] > dot[2]) ? (0) : ((dot[0] > dot[2]) ? (0) : (2))) : ((dot[2] > dot[1]) ? (2) : (1));
}
