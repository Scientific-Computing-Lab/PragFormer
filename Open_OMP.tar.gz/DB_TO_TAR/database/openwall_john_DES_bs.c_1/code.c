for (t = 0; t < (n * (((sizeof(DES_bs_combined)) + (64 - 1)) & (~(64 - 1)))); t += ((sizeof(DES_bs_combined)) + (64 - 1)) & (~(64 - 1)))
{
  k = (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).KS.p;
  s = 0;
  for (round = 0; round < 16; round++)
  {
    s += DES_ROT[round];
    for (index = 0; index < 48; index++)
    {
      p = DES_PC2[index];
      q = (p < 28) ? (0) : (28);
      p += s;
      while (p >= 28)
        p -= 28;

      bit = DES_PC1[p + q];
      bit ^= 070;
      bit -= bit >> 3;
      bit = 55 - bit;
      if (LM == 1)
        bit = DES_LM_KP[bit];

      *(k++) = &(*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).K[bit];
    }

  }

  for (index = 0; index < ARCH_BITS; index++)
    (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).pxkeys[index] = &(*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).xkeys.c[0][index & 7][index >> 3];

  if (LM == 1)
  {
    for (c = 0; c < 0x100; c++)
      (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).E.u[c] = CP_up[c];

  }
  else
    if (LM == 0)
  {
    for (index = 0; index < 48; index++)
      (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).Ens[index] = &(*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).B[DES_E[index]];

    (*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).salt = 0xffffff;
    DES_bs_set_salt_for_thread(t, 0);
  }


  memset(&(*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).zero, 0, sizeof((*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).zero));
  memset(&(*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).ones, -1, sizeof((*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).ones));
  for (bit = 0; bit < 8; bit++)
    memset(&(*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).masks[bit], 1 << bit, sizeof((*((DES_bs_combined *) (((char *) DES_bs_all_p) + t))).masks[bit]));

}
