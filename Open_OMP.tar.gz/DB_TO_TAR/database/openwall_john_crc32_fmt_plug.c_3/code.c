for (i = 0; i < count; ++i)
  if (crc == crcs[i])
  return 1;

