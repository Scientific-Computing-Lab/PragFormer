for (i = 1; i < m_ompt; ++i)
  md5_unicode_convert[i] = what;
