for (i = 0; i < count; i++)
{
  if (!(((uint32_t *) binary)[0] - crypt_key_X86[i >> MD5_X2].x1.w[0]))
    return 1;

}
