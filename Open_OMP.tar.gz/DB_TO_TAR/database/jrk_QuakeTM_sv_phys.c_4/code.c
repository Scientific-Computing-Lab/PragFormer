for (i = 0; i < 3; i++)
{
  mins[i] = pusher->v.absmin[i] + move[i];
  maxs[i] = pusher->v.absmax[i] + move[i];
}
