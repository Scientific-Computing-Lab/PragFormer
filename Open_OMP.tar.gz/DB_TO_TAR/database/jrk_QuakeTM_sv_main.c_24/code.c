for (i = 0; i < 256; i++)
  sprintf(localmodels[i], "*%i", i);
