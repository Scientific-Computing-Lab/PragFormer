for (index = 0; index < count; index++)
{
  if ((*((uint32_t *) binary)) == crypt_out[index][0])
    return 1;

  if ((*((uint32_t *) binary)) == crypt_out[index][1])
    return 1;

}
