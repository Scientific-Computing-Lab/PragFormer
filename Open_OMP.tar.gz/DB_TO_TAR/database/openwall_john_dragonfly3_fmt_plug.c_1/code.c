for (pos = ciphertext; (*pos) && ((*pos) != '$'); pos++)
  ;
