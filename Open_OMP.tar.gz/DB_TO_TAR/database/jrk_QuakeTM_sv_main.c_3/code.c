for (frame = cl->frames, i = 0; i < 64; i++, frame++)
{
  if (frame->ping_time > 0)
  {
    ping += frame->ping_time;
    count++;
  }

}
