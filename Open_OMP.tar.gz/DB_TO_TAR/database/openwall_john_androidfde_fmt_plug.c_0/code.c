for (index = 0; index < count; index += 1)
{
  hash_plugin_check_hash(index);
}

void hash_plugin_check_hash(int index)
{
  unsigned char keycandidate2[255];
  unsigned char decrypted1[512];
  unsigned char decrypted2[512];
  AES_KEY aeskey;
  uint16_t v2;
  uint16_t v3;
  uint16_t v4;
  uint32_t v1;
  uint32_t v5;
  int j = 0;
  unsigned char keycandidate[255];
  char *password = saved_key[index];
  pbkdf2_sha1((const uint8_t *) password, strlen(password), (const uint8_t *) cur_salt->salt, 16, 2000, keycandidate, cur_salt->keysize + 16, 0);
  j = 0;
  JTR_AES_set_decrypt_key(keycandidate, cur_salt->keysize * 8, &aeskey);
  JTR_AES_cbc_encrypt(cur_salt->mkey, keycandidate2, 16, &aeskey, keycandidate + 16, 0);
  AES_cbc_essiv(cur_salt->data, decrypted1, keycandidate2, 0, 32);
  AES_cbc_essiv(cur_salt->data + 1024, decrypted2, keycandidate2, 2, 128);
  if (!memcmp(decrypted1 + 3, "MSDOS5.0", 8))
    cracked[index + j] = 1;
  else
  {
    memcpy(&v1, decrypted2 + 72, 4);
    memcpy(&v2, decrypted2 + 0x3a, 2);
    memcpy(&v3, decrypted2 + 0x3c, 2);
    memcpy(&v4, decrypted2 + 0x4c, 2);
    memcpy(&v5, decrypted2 + 0x48, 4);
    v1 = __builtin_bswap32(v1);
    v2 = __builtin_bswap32(v2);
    v3 = __builtin_bswap32(v3);
    v4 = __builtin_bswap32(v4);
    v5 = __builtin_bswap32(v5);
    if (((((v1 < 5) && (v2 < 4)) && (v3 < 5)) && (v4 < 2)) && (v5 < 5))
      cracked[index + j] = 1;

  }

}

