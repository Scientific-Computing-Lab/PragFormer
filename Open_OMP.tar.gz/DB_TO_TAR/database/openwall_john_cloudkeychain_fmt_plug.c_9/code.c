for (i = 0; i < cs.hmacdatalen; i++)
  cs.hmacdata[i] = (atoi16[ARCH_INDEX(p[i * 2])] * 16) + atoi16[ARCH_INDEX(p[(i * 2) + 1])];
