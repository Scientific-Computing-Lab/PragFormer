for (i = 0; i < 2; i++)
  gefvCache[i].field[0] = 0;
