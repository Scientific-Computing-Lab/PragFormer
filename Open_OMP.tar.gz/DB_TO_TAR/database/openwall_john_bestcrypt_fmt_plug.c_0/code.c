for (index = 0; index < count; index += 1)
{
  if (cur_salt->hash_id == (0x80 + 1))
  {
    unsigned char key[64];
    int keylen = 0;
    pbe_format_v5_64 *pbe64;
    unsigned char out[256] = {0};
    AES_KEY aes_key;
    sph_whirlpool_context ctx;
    unsigned char hash[64];
    unsigned char iv[16] = {0};
    struct KGEncryptedBlock64 *p;
    if (cur_salt->mode_id == 0xBC000004)
      keylen = 64;
    else
      if (cur_salt->mode_id == 0xBC000002)
      keylen = 32;


    pkcs12_pbe_derive_key(2, cur_salt->iterations, 1, (unsigned char *) saved_key[index], saved_len[index], cur_salt->salt, cur_salt->salt_size, key, keylen);
    pbe64 = (pbe_format_v5_64 *) cur_salt->key;
    memcpy(iv, pbe64->iv, 8);
    if (cur_salt->mode_id == 0xBC000004)
    {
      AES_XTS_decrypt_custom_tweak(key, iv, out, pbe64->keyblock, 256, 256);
    }

    if (cur_salt->mode_id == 0xBC000002)
    {
      memcpy(iv + 8, pbe64->iv, 8);
      JTR_AES_set_decrypt_key(key, 256, &aes_key);
      JTR_AES_cbc_encrypt(pbe64->keyblock, out, 160, &aes_key, iv, 0);
    }

    sph_whirlpool_init(&ctx);
    sph_whirlpool(&ctx, out, 90);
    sph_whirlpool_close(&ctx, hash);
    p = (struct KGEncryptedBlock64 *) out;
    cracked[index] = 0 == memcmp(hash, p->digest, 32);
  }
  else
    if (cur_salt->hash_id == 0x80)
  {
    unsigned char key[64];
    int keylen = 0;
    pbe_format_v5_32 *pbe32;
    unsigned char out[256] = {0};
    AES_KEY aes_key;
    jtr_sha256_ctx ctx;
    unsigned char hash[32];
    unsigned char iv[16] = {0};
    struct KGEncryptedBlock32 *p;
    if (cur_salt->mode_id == 0xBC000004)
      keylen = 64;
    else
      if (cur_salt->mode_id == 0xBC000002)
      keylen = 32;


    pkcs12_pbe_derive_key(256, cur_salt->iterations, 1, (unsigned char *) saved_key[index], saved_len[index], cur_salt->salt, cur_salt->salt_size, key, keylen);
    pbe32 = (pbe_format_v5_32 *) cur_salt->key;
    memcpy(iv, pbe32->iv, 8);
    if (cur_salt->mode_id == 0xBC000004)
    {
      AES_XTS_decrypt_custom_tweak(key, iv, out, pbe32->keyblock, 256, 256);
    }
    else
      if (cur_salt->mode_id == 0xBC000002)
    {
      memcpy(iv + 8, pbe32->iv, 8);
      JTR_AES_set_decrypt_key(key, 256, &aes_key);
      JTR_AES_cbc_encrypt(pbe32->keyblock, out, 128, &aes_key, iv, 0);
    }


    jtr_sha256_init(&ctx, 1);
    jtr_sha256_update(&ctx, out, 90);
    jtr_sha256_final(hash, &ctx);
    p = (struct KGEncryptedBlock32 *) out;
    cracked[index] = 0 == memcmp(hash, p->digest, 32);
  }
  else
    if (cur_salt->hash_id == 10)
  {
    unsigned char key[64];
    int keylen = 0;
    pbe_format_v5_64 *pbe64;
    unsigned char out[256] = {0};
    AES_KEY aes_key;
    jtr_sha512_ctx ctx;
    unsigned char hash[64];
    unsigned char iv[16] = {0};
    struct KGEncryptedBlock64 *p;
    if (cur_salt->mode_id == 0xBC000004)
      keylen = 64;
    else
      if (cur_salt->mode_id == 0xBC000002)
      keylen = 32;


    pkcs12_pbe_derive_key(10, cur_salt->iterations, 1, (unsigned char *) saved_key[index], saved_len[index], cur_salt->salt, cur_salt->salt_size, key, keylen);
    pbe64 = (pbe_format_v5_64 *) cur_salt->key;
    memcpy(iv, pbe64->iv, 8);
    if (cur_salt->mode_id == 0xBC000004)
    {
      AES_XTS_decrypt_custom_tweak(key, iv, out, pbe64->keyblock, 256, 256);
    }
    else
      if (cur_salt->mode_id == 0xBC000002)
    {
      memcpy(iv + 8, pbe64->iv, 8);
      JTR_AES_set_decrypt_key(key, 256, &aes_key);
      JTR_AES_cbc_encrypt(pbe64->keyblock, out, 160, &aes_key, iv, 0);
    }


    jtr_sha512_init(&ctx, 1);
    jtr_sha512_update(&ctx, out, 90);
    jtr_sha512_final(hash, &ctx);
    p = (struct KGEncryptedBlock64 *) out;
    cracked[index] = 0 == memcmp(hash, p->digest, 32);
  }



}
