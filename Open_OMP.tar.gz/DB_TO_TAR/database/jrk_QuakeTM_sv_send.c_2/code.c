for (i = 0; i < 32; i++)
{
  c = &svs.clients[i];
  if (!c->state)
    continue;

  int ThreadId = ThreadNumber();
  inTransaction = true;
  if (c->drop)
  {
    SV_DropClient(c);
    c->drop = false;
  }
  else
  {
    if (c->num_backbuf)
    {
      if ((c->netchan.message.cursize + c->backbuf_size[0]) < c->netchan.message.maxsize)
      {
        Con_DPrintf("%s: backbuf %d bytes\n", c->name, c->backbuf_size[0]);
        SZ_Write(&c->netchan.message, c->backbuf_data[0], c->backbuf_size[0]);
        for (j = 1; j < c->num_backbuf; j++)
        {
          Q_memcpy(c->backbuf_data[j - 1], c->backbuf_data[j], c->backbuf_size[j]);
          c->backbuf_size[j - 1] = c->backbuf_size[j];
        }

        c->num_backbuf--;
        if (c->num_backbuf)
        {
          Q_memset(&c->backbuf, 0, sizeof(c->backbuf));
          c->backbuf.data = c->backbuf_data[c->num_backbuf - 1];
          c->backbuf.cursize = c->backbuf_size[c->num_backbuf - 1];
          c->backbuf.maxsize = sizeof(c->backbuf_data[c->num_backbuf - 1]);
        }

      }

    }

    if (c->netchan.message.overflowed)
    {
      SZ_Clear(&c->netchan.message);
      SZ_Clear(&c->datagram);
      SV_BroadcastPrintf(2, "%s overflowed\n", c->name);
      Con_Printf("WARNING: reliable overflow for %s\n", c->name);
      SV_DropClient(c);
      c->send_message = true;
      c->netchan.cleartime = 0;
    }

    if (c->send_message)
    {
      if (((DEBUG & (~0x03)) & 16) && ((DEBUG & 0x03) >= 2))
        printf("Thread: %d\tShould send to %s\n", ThreadId, c->name);

      c->send_message = false;
      if ((!sv.paused) && (!Netchan_CanPacket(&c->netchan)))
      {
        if (((DEBUG & (~0x03)) & 16) && ((DEBUG & 0x03) >= 2))
          printf("Thread: %d\tChoke for %s\n", ThreadId, c->name);

        c->chokecount++;
      }
      else
      {
        if (c->state == cs_spawned)
          SV_SendClientDatagram(c);
        else
          Netchan_Transmit(&c->netchan, 0, 0);

      }

    }

  }

  inTransaction = false;
  FlushTMOutput();
}

void Con_DPrintf(char *fmt, ...)
{
  va_list argptr;
  char msg[8192];
  if (!developer.value)
    return;

  __builtin_va_start(argptr);
  Q_vsprintf(msg, fmt, argptr);
  ;
  Con_Printf("%s", msg);
}


void SV_BroadcastPrintf(int level, char *fmt, ...)
{
  va_list argptr;
  char string[1024];
  client_t *cl;
  int i;
  __builtin_va_start(argptr);
  Q_vsprintf(string, fmt, argptr);
  ;
  Sys_Printf("%s", string);
  for (i = 0, cl = svs.clients; i < 32; i++, cl++)
  {
    if (level < cl->messagelevel)
      continue;

    if (!cl->state)
      continue;

    SV_PrintToClient(cl, level, string);
  }

}


void Con_Printf(char *fmt, ...)
{
  va_list argptr;
  char msg[8192];
  __builtin_va_start(argptr);
  Q_vsprintf(msg, fmt, argptr);
  ;
  if (sv_redirected)
  {
    if ((Q_strlen(msg) + Q_strlen(outputbuf)) > ((8192 * (sizeof(char))) - 1))
      SV_FlushRedirect();

    Q_strcat(outputbuf, msg);
    return;
  }

  if (inTransaction == true)
  {
    AddMsg2List(false, msg);
    return;
  }

  Sys_Printf("%s", msg);
  if (sv_logfile)
    fprintf(sv_logfile, "%s", msg);

}


qboolean SV_SendClientDatagram(client_t *client)
{
  byte buf[1450];
  sizebuf_t msg;
  msg.data = buf;
  msg.maxsize = sizeof(buf);
  msg.cursize = 0;
  msg.allowoverflow = true;
  msg.overflowed = false;
  SV_WriteClientdataToMessage(client, &msg);
  SV_WriteEntitiesToClient(client, &msg);
  if (client->datagram.overflowed)
    Con_Printf("WARNING: datagram overflowed for %s\n", client->name);
  else
    SZ_Write(&msg, client->datagram.data, client->datagram.cursize);

  SZ_Clear(&client->datagram);
  if (Netchan_CanReliable(&client->netchan))
    SV_UpdateClientStats(client);

  if (msg.overflowed)
  {
    Con_Printf("WARNING: msg overflowed for %s\n", client->name);
    SZ_Clear(&msg);
  }

  Netchan_Transmit(&client->netchan, msg.cursize, buf);
  return true;
}

