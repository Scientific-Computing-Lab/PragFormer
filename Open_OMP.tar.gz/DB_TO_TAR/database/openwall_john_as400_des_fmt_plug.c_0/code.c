for (index = 0; index < count; index++)
{
  DES_cblock des_key;
  DES_key_schedule schedule;
  int i;
  int saved_key_length = strlen(saved_key[index]);
  if (saved_key_length <= 8)
  {
    for (i = 0; saved_key[index][i]; i++)
      des_key[i] = a2e_precomputed[ARCH_INDEX(saved_key[index][i])];

    while (i < 8)
      des_key[i++] = 0x2a;

    DES_set_key_unchecked(&des_key, &schedule);
    DES_ecb_encrypt((const_DES_cblock *) cur_salt->userid, (DES_cblock *) crypt_out[index], &schedule, 1);
  }
  else
  {
    DES_cblock des_key1;
    DES_cblock des_key2;
    DES_key_schedule schedule1;
    DES_key_schedule schedule2;
    DES_cblock hash_1;
    DES_cblock hash_2;
    unsigned char output[8];
    for (i = 0; i < 8; i++)
      des_key1[i] = a2e_precomputed[ARCH_INDEX(saved_key[index][i])];

    for (i = 0; i < (saved_key_length - 8); i++)
      des_key2[i] = a2e_precomputed[ARCH_INDEX(saved_key[index][8 + i])];

    while (i < 8)
      des_key2[i++] = 0x2a;

    DES_set_key_unchecked(&des_key1, &schedule1);
    DES_ecb_encrypt((const_DES_cblock *) cur_salt->userid, &hash_1, &schedule1, 1);
    DES_set_key_unchecked(&des_key2, &schedule2);
    DES_ecb_encrypt((const_DES_cblock *) cur_salt->userid, &hash_2, &schedule2, 1);
    for (i = 0; i < 8; i++)
    {
      output[i] = hash_1[i] ^ hash_2[i];
    }

    memcpy((unsigned char *) crypt_out[index], output, 8);
  }

}
