for (j = 48; j > 32; j--)
{
  state[p - x.c] = (t = (*p) ^ lotus_magic_table[j + t]);
  p++;
}
