for (i = 0, c = svs.clients; i < 32; i++, c++)
  if (c->state)
  c->send_message = true;

