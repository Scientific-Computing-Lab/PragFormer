for (i = 0; i < (2 * 8); ++i)
  es_salt[i] = (atoi16[ARCH_INDEX(ciphertext[i * 2])] << 4) + atoi16[ARCH_INDEX(ciphertext[(i * 2) + 1])];
