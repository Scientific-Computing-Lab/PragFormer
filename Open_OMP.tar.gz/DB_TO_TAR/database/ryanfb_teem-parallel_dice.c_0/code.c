for (pos = 0; pos < nin->axis[axis].size; pos++)
{
  if ((nout == 0) && (nnout == 0))
  {
    nout = nrrdNew();
    airMopAdd(mop, nout, (airMopper) nrrdNuke, airMopAlways);
    nnout = (Nrrd **) malloc(sizeof(Nrrd *));
    nnout[0] = nout;
  }

  if (nrrdSlice(nout, nin, axis, pos))
  {
    airMopAdd(mop, err = biffGetDone(nrrdBiffKey), airFree, airMopAlways);
    fprintf(stderr, "%s: error slicing nrrd:%s\n", me, err);
    airMopError(mop);
    abort = 1;
  }

  fprintf(stderr, "%s: ", me);
  fprintf(stderr, fnout, pos + start);
  fprintf(stderr, " ...\n");
  if (nrrdSaveMulti(fnout, (const Nrrd * const *) nnout, 1, pos + start, 0))
  {
    airMopAdd(mop, err = biffGetDone(nrrdBiffKey), airFree, airMopAlways);
    fprintf(stderr, "%s: error writing nrrd to \"%s\":%s\n", me, fnout, err);
    airMopError(mop);
    abort = 1;
  }

}
