for (i = 1; i < m_ompt; ++i)
  dyna_nLargeOff[i] = val;
