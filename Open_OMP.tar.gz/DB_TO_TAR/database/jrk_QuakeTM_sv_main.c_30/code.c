for (p = (newname + Q_strlen(newname)) - 1; (p != newname) && ((((*p) == ' ') || ((*p) == '\r')) || ((*p) == '\n')); p--)
  ;
