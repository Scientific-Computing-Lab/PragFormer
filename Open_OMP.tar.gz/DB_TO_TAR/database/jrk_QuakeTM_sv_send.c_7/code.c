for (i = 0; i < 3; i++)
  MSG_WriteCoord(&sv.multicast, origin[i]);
