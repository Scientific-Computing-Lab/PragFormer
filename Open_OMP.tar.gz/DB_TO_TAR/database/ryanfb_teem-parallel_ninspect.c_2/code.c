for (ii = 0; ii < 3; ii++)
{
  if (h[map[ii]] != map[h[ii]])
  {
    if (!E)
      E |= nrrdAxesSwap(ntmp[ii], nproj[map[ii]], 1, 2);

  }
  else
  {
    if (!E)
      E |= nrrdCopy(ntmp[ii], nproj[map[ii]]);

  }

}
