for (i = 0; i < size; i++)
{
  buff[i] = (atoi16[ARCH_INDEX(ciphertext[i * 2])] * 16) + atoi16[ARCH_INDEX(ciphertext[(i * 2) + 1])];
}
