for (n = 65; (n < 105) && (atoi16u[ARCH_INDEX(ciphertext[n])] != 0x7F); ++n)
  ;
