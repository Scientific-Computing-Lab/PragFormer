for (index = 0; index < count; index += 1)
{
  unsigned char *passwordBuf;
  int passwordBufSize;
  unsigned char *sidBuf;
  int sidBufSize;
  unsigned char out[1][32 + 16];
  unsigned char out2[1][32 + 16];
  sph_sha1_context ctx;
  MD4_CTX ctx2;
  int i;
  int digestlens[1];
  for (i = 0; i < 1; ++i)
  {
    digestlens[i] = 16;
    passwordBuf = (unsigned char *) saved_key[index + i];
    passwordBufSize = strlen16((UTF16 *) passwordBuf) * 2;
    if (cur_salt->cred_type == 1)
    {
      sph_sha1_init(&ctx);
      sph_sha1(&ctx, passwordBuf, passwordBufSize);
      sph_sha1_close(&ctx, out[i]);
      digestlens[i] = 20;
    }
    else
      if ((cur_salt->cred_type == 2) || (cur_salt->cred_type == 3))
    {
      john_MD4_Init(&ctx2);
      john_MD4_Update(&ctx2, passwordBuf, passwordBufSize);
      john_MD4_Final(out[i], &ctx2);
      digestlens[i] = 16;
    }


  }

  if (cur_salt->cred_type == 3)
  {
    sidBuf = (unsigned char *) cur_salt->SID;
    sidBufSize = strlen16(cur_salt->SID) * 2;
    for (i = 0; i < 1; ++i)
    {
      pbkdf2_sha256(out[i], 16, sidBuf, sidBufSize, 10000, out2[i], 32, 0);
      pbkdf2_sha256(out2[i], 32, sidBuf, sidBufSize, 1, out[i], 16, 0);
    }

  }

  for (i = 0; i < 1; ++i)
  {
    passwordBuf = (unsigned char *) cur_salt->SID;
    passwordBufSize = (strlen16(cur_salt->SID) + 1) * 2;
    JTR_hmac_sha1(out[i], digestlens[i], passwordBuf, passwordBufSize, out2[i], 20);
  }

  if (cur_salt->version == 1)
    pbkdf2_sha1(out2[0], 20, cur_salt->iv, 16, cur_salt->pbkdf2_iterations, out[0], 24 + 8, 0);
  else
    if (cur_salt->version == 2)
    pbkdf2_sha512(out2[0], 20, cur_salt->iv, 16, cur_salt->pbkdf2_iterations, out[0], 32 + 16, 0);


  if (cur_salt->version == 1)
  {
    for (i = 0; i < 1; ++i)
    {
      memset(out2[i] + 20, 0, 32 - 20);
      if (decrypt_v1(out[i], out[i] + 24, out2[i], cur_salt->encrypted) == 0)
        cracked[index + i] = 1;
      else
        cracked[index + i] = 0;

    }

  }
  else
    if (cur_salt->version == 2)
  {
    for (i = 0; i < 1; ++i)
    {
      if (decrypt_v2(out[i], out[i] + 32, out2[i], cur_salt->encrypted) == 0)
        cracked[index + i] = 1;
      else
        cracked[index + i] = 0;

    }

  }


}

static void pbkdf2_sha256(const unsigned char *K, int KL, unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[32 / (sizeof(uint32_t))];
    unsigned char out[32];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  jtr_sha256_ctx ipad;
  jtr_sha256_ctx opad;
  _pbkdf2_sha256_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (32 - 1)) / 32;
  loop = (skip_bytes / 32) + 1;
  skip_bytes %= 32;
  while (loop <= loops)
  {
    _pbkdf2_sha256(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 32) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}


static void pbkdf2_sha256(const unsigned char *K, int KL, unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[32 / (sizeof(uint32_t))];
    unsigned char out[32];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  jtr_sha256_ctx ipad;
  jtr_sha256_ctx opad;
  _pbkdf2_sha256_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (32 - 1)) / 32;
  loop = (skip_bytes / 32) + 1;
  skip_bytes %= 32;
  while (loop <= loops)
  {
    _pbkdf2_sha256(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 32) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}


static void pbkdf2_sha1(const unsigned char *K, int KL, const unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint32_t x32[20 / (sizeof(uint32_t))];
    unsigned char out[20];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  sph_sha1_context ipad;
  sph_sha1_context opad;
  _pbkdf2_sha1_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (20 - 1)) / 20;
  loop = (skip_bytes / 20) + 1;
  skip_bytes %= 20;
  while (loop <= loops)
  {
    _pbkdf2_sha1(S, SL, R, tmp.x32, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 20) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}


static void pbkdf2_sha512(const unsigned char *K, int KL, unsigned char *S, int SL, int R, unsigned char *out, int outlen, int skip_bytes)
{
  union 
  {
    uint64_t x64[64 / (sizeof(uint64_t))];
    unsigned char out[64];
  } tmp;
  int loop;
  int loops;
  int i;
  int accum = 0;
  jtr_sha512_ctx ipad;
  jtr_sha512_ctx opad;
  _pbkdf2_sha512_load_hmac(K, KL, &ipad, &opad);
  loops = ((skip_bytes + outlen) + (64 - 1)) / 64;
  loop = (skip_bytes / 64) + 1;
  skip_bytes %= 64;
  while (loop <= loops)
  {
    _pbkdf2_sha512(S, SL, R, tmp.x64, loop, &ipad, &opad);
    for (i = skip_bytes; (i < 64) && (accum < outlen); i++)
    {
      out[accum++] = ((uint8_t *) tmp.out)[i];
    }

    loop++;
    skip_bytes = 0;
  }

}


static int decrypt_v1(unsigned char *key, unsigned char *iv, unsigned char *pwdhash, unsigned char *data)
{
  unsigned char out[4096 + 16];
  unsigned char *last_key;
  unsigned char *hmacSalt;
  unsigned char *expected_hmac;
  unsigned char computed_hmac[20];
  unsigned char encKey[20];
  DES_cblock ivec;
  DES_key_schedule ks1;
  DES_key_schedule ks2;
  DES_key_schedule ks3;
  memset(out, 0, sizeof(out));
  DES_set_key_unchecked((DES_cblock *) key, &ks1);
  DES_set_key_unchecked((DES_cblock *) (key + 8), &ks2);
  DES_set_key_unchecked((DES_cblock *) (key + 16), &ks3);
  memcpy(ivec, iv, 8);
  DES_ede3_cbc_encrypt(data, out, cur_salt->encrypted_len, &ks1, &ks2, &ks3, &ivec, 0);
  hmacSalt = out;
  expected_hmac = out + 16;
  last_key = (out + cur_salt->encrypted_len) - 64;
  JTR_hmac_sha1(pwdhash, 32, hmacSalt, 16, encKey, 20);
  JTR_hmac_sha1(encKey, 20, last_key, 64, computed_hmac, 20);
  return memcmp(expected_hmac, computed_hmac, 20);
}


static int decrypt_v2(unsigned char *key, unsigned char *iv, unsigned char *pwdhash, unsigned char *data)
{
  unsigned char out[4096 + 16];
  unsigned char *last_key;
  unsigned char *hmacSalt;
  unsigned char *expected_hmac;
  unsigned char hmacComputed[64];
  unsigned char encKey[64];
  AES_KEY aeskey;
  JTR_AES_set_decrypt_key(key, 32 * 8, &aeskey);
  JTR_AES_cbc_encrypt(data, out, cur_salt->encrypted_len, &aeskey, iv, 0);
  hmacSalt = out;
  expected_hmac = out + 16;
  last_key = (out + cur_salt->encrypted_len) - 64;
  JTR_hmac_sha512(pwdhash, 20, hmacSalt, 16, encKey, 64);
  JTR_hmac_sha512(encKey, 64, last_key, 64, hmacComputed, 64);
  return memcmp(expected_hmac, hmacComputed, 64);
}

