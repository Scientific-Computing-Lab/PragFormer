for (i = 0; i < 16; i++)
{
  p = x.c;
  for (j = 48; j > 0; j--)
  {
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[(j--) + t]);
    t = (*(p++) ^= lotus_magic_table[j + t]);
  }

}
