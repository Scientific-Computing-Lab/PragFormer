for (i = 0; i < 16; i++)
{
  p0 = x[0].c;
  p1 = x[1].c;
  p2 = x[2].c;
  for (j = 48; j > 0; j--)
  {
    t0 = (*(p0++) ^= lotus_magic_table[j + t0]);
    t1 = (*(p1++) ^= lotus_magic_table[j + t1]);
    t2 = (*(p2++) ^= lotus_magic_table[(j--) + t2]);
    t0 = (*(p0++) ^= lotus_magic_table[j + t0]);
    t1 = (*(p1++) ^= lotus_magic_table[j + t1]);
    t2 = (*(p2++) ^= lotus_magic_table[(j--) + t2]);
    t0 = (*(p0++) ^= lotus_magic_table[j + t0]);
    t1 = (*(p1++) ^= lotus_magic_table[j + t1]);
    t2 = (*(p2++) ^= lotus_magic_table[(j--) + t2]);
    t0 = (*(p0++) ^= lotus_magic_table[j + t0]);
    t1 = (*(p1++) ^= lotus_magic_table[j + t1]);
    t2 = (*(p2++) ^= lotus_magic_table[j + t2]);
  }

}
