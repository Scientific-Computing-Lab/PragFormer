for (i = 0; i < saved_key_len[index]; ++i)
  out[i] = cp[i];
