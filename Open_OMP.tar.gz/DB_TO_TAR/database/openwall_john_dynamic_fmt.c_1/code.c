for (j = 0; j < m_Dynamic_Count; j += inc)
{
  unsigned int i;
  unsigned int top = j + inc;
  if (top > Dynamic_curdat.pFmtMain->params.max_keys_per_crypt)
    top = Dynamic_curdat.pFmtMain->params.max_keys_per_crypt;

  for (i = 0; Dynamic_curdat.dynamic_FUNCTIONS[i]; ++i)
    (*Dynamic_curdat.dynamic_FUNCTIONS[i])(j, top, omp_get_thread_num());

}
