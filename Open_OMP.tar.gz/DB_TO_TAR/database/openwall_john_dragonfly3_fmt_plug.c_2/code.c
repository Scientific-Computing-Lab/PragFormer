for (i = 0; i < 10; i++)
{
  value = ((((uint32_t) atoi64[ARCH_INDEX(pos[0])]) | (((uint32_t) atoi64[ARCH_INDEX(pos[1])]) << 6)) | (((uint32_t) atoi64[ARCH_INDEX(pos[2])]) << 12)) | (((uint32_t) atoi64[ARCH_INDEX(pos[3])]) << 18);
  pos += 4;
  out[i] = value >> 16;
  out[i + 11] = value >> 8;
  out[i + 21] = value;
  ;
}
