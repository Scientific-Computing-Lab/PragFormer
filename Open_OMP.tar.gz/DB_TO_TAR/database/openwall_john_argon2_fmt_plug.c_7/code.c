for (i = 0; i < sc_threads; i++)
  pseudo_rands[i] = mem_calloc(sizeof(uint64_t), segment_length);
