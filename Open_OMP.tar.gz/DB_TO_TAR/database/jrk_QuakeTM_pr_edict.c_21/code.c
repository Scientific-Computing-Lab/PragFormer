for (i = 0; i < progs->numglobals; i++)
  ((int *) pr_globals_temp)[i] = LittleLong(((int *) pr_globals_temp)[i]);
