for (i = 0; i < salt->salt_length; i++)
{
  hash <<= 1;
  hash += (unsigned char) (*(p++));
  if (hash >> 20)
  {
    hash ^= hash >> 20;
    hash &= (1 << 20) - 1;
  }

}
