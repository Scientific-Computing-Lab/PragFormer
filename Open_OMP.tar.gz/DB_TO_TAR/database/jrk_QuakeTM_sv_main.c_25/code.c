for (i = 0; i < 32; i++)
  if ((svs.clients[i].state == cs_connected) || (svs.clients[i].state == cs_spawned))
  active++;

