for (index = 0; index < count; index += 1)
{
  jtr_sha512_ctx ctx;
  unsigned char tmp[(512 / 8) + 47];
  int len = EncKeyLen[index];
  unsigned Lcount = loopCnt - 1;
  jtr_sha512_init(&ctx, 1);
  jtr_sha512_update(&ctx, cursalt, 8);
  jtr_sha512_update(&ctx, EncKey[index], len);
  memcpy(&tmp[512 / 8], (char *) EncKey[index], len);
  jtr_sha512_final(tmp, &ctx);
  len += 512 / 8;
  do
  {
    jtr_sha512_init(&ctx, 1);
    jtr_sha512_update(&ctx, tmp, len);
    jtr_sha512_final(tmp, &ctx);
  }
  while (--Lcount);
  jtr_sha512_init(&ctx, 1);
  jtr_sha512_update(&ctx, tmp, len);
  jtr_sha512_final((unsigned char *) crypt_key[index], &ctx);
}
