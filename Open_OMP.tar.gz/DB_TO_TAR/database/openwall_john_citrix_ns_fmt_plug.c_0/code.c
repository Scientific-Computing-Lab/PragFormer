for (index = 0; index < loops; ++index)
{
  sph_sha1_context ctx;
  sph_sha1_init(&ctx);
  sph_sha1(&ctx, (unsigned char *) saved_salt, 8);
  sph_sha1(&ctx, (unsigned char *) saved_key[index], strlen(saved_key[index]) + 1);
  sph_sha1_close(&ctx, (unsigned char *) crypt_key[index]);
}
