for (i = 0, client = svs.clients; i < 32; i++, client++)
{
  if ((client->state != cs_spawned) || (client == cl))
    continue;

  if (!Q_strcasecmp(client->name, val))
    break;

}
